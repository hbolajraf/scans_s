#!/bin/bash
# =============================================================================
# confluence.sh
# Confluence API wrapper with attachment create/update support.
# =============================================================================

source ./scripts/config/config.sh
source ./scripts/common.sh

CreatePage(){
  local title="$1"
  local subtitle="$2"
  local parent_id="$3"
  local space="$4"
  local payload_file="${TMP_DIR}/confluence-create-page-$(date +%s%N).json"
  local response_file="${TMP_DIR}/confluence-create-page-response-$(date +%s%N).json"
  local http_code
  local page_id

  mkdir -p "$TMP_DIR"

  LogInfo "Creating Confluence page: ${title}"

  if [[ -z "$parent_id" || ! "$parent_id" =~ ^[0-9]+$ ]]; then
    LogError "Invalid Confluence parent page ID: '${parent_id}'"
    return 1
  fi

  if [[ -z "$space" ]]; then
    LogError "Invalid Confluence space key: empty value"
    return 1
  fi

  # Build JSON safely. This prevents HTTP 400 caused by unescaped quotes
  # in page titles or HTML body content.
  jq -n \
    --arg title "$title" \
    --arg subtitle "$subtitle" \
    --arg space "$space" \
    --argjson parent_id "$parent_id" \
    '{
      type: "page",
      title: $title,
      ancestors: [{id: $parent_id}],
      space: {key: $space},
      body: {
        storage: {
          value: $subtitle,
          representation: "storage"
        }
      }
    }' > "$payload_file"

  http_code=$(curl --silent --show-error \
    --request POST \
    --url "${CONFLUENCE_BASE_URL}/rest/api/content/" \
    --header "Authorization: Bearer ${CONFLUENCE_TOKEN}" \
    --header "Content-Type: application/json" \
    --data @"${payload_file}" \
    --output "$response_file" \
    --write-out "%{http_code}")

  if [[ "$http_code" -lt 200 || "$http_code" -gt 299 ]]; then
    LogError "Confluence page creation failed with HTTP ${http_code}: title='${title}', parent='${parent_id}', space='${space}'"
    LogError "Confluence response: $(cat "$response_file" | head -c 1200)"
    LogError "Payload file kept for debug: ${payload_file}"
    return 1
  fi

  page_id=$(jq -r '.id // empty' "$response_file")

  if [[ -z "$page_id" ]]; then
    LogError "Confluence page creation succeeded but no page ID was returned for title='${title}'"
    LogError "Confluence response: $(cat "$response_file" | head -c 1200)"
    return 1
  fi

  rm -f "$payload_file" "$response_file"

  LogInfo "Confluence page created: ${page_id}"
  echo "$page_id"
}


GetPageContent(){
  local page_id="$1"
  curl --silent --show-error --fail \
    -H "Authorization: Bearer ${CONFLUENCE_TOKEN}" \
    "${CONFLUENCE_BASE_URL}/rest/api/content/${page_id}?expand=body.storage,version,space"
}

AppendStorageToPage(){
  local page_id="$1"
  local fragment="$2"
  local tmp="${TMP_DIR}/page-${page_id}.json"
  local response_file="${TMP_DIR}/confluence-update-page-response-${page_id}-$(date +%s%N).json"
  local http_code

  mkdir -p "$TMP_DIR"

  GetPageContent "$page_id" |
    jq --arg fragment "$fragment" '{
      body:{storage:{value:(.body.storage.value + $fragment), representation:.body.storage.representation}},
      id:.id,
      type:.type,
      title:.title,
      space:{key:.space.key},
      version:{number:(.version.number + 1)}
    }' > "$tmp"

  http_code=$(curl --silent --show-error \
    -H "Authorization: Bearer ${CONFLUENCE_TOKEN}" \
    -X PUT \
    -H "Content-Type: application/json" \
    --data @"$tmp" \
    "${CONFLUENCE_BASE_URL}/rest/api/content/${page_id}" \
    --output "$response_file" \
    --write-out "%{http_code}")

  if [[ "$http_code" -lt 200 || "$http_code" -gt 299 ]]; then
    LogError "Confluence page update failed with HTTP ${http_code}: page_id='${page_id}'"
    LogError "Confluence response: $(cat "$response_file" | head -c 1200)"
    LogError "Payload file kept for debug: ${tmp}"
    return 1
  fi

  rm -f "$tmp" "$response_file"
}


UpdatePageWithHtmlContent(){
  local page_id="$1"; local html="$2"
  local macro_uuid
  macro_uuid=$(uuidgen 2>/dev/null || date +%s%N)
  AppendStorageToPage "$page_id" "<ac:structured-macro ac:name=\"html\" ac:schema-version=\"1\" ac:macro-id=\"${macro_uuid}\"><ac:plain-text-body><![CDATA[${html}]]></ac:plain-text-body></ac:structured-macro>"
}

UpdatePageWithBarChartMacro(){
  local page_id="$1"; local file_name="$2"; local title="$3"
  local macro_uuid content
  macro_uuid=$(uuidgen 2>/dev/null || date +%s%N)
  content=$(cat "$file_name")
  AppendStorageToPage "$page_id" "<ac:macro ac:name=\"chart\" ac:macro-id=\"${macro_uuid}\"><ac:parameter ac:name=\"title\">${title}</ac:parameter><ac:parameter ac:name=\"type\">bar</ac:parameter><ac:parameter ac:name=\"orientation\">vertical</ac:parameter><ac:parameter ac:name=\"width\">900</ac:parameter><ac:parameter ac:name=\"height\">520</ac:parameter><ac:parameter ac:name=\"legend\">true</ac:parameter><ac:parameter ac:name=\"dataOrientation\">vertical</ac:parameter><ac:rich-text-body>${content}</ac:rich-text-body></ac:macro>"
}

UpdatePageWithPieChartMacro(){
  local page_id="$1"; local file_name="$2"; local title="$3"
  local macro_uuid content
  macro_uuid=$(uuidgen 2>/dev/null || date +%s%N)
  content=$(cat "$file_name")
  AppendStorageToPage "$page_id" "<ac:macro ac:name=\"chart\" ac:macro-id=\"${macro_uuid}\"><ac:parameter ac:name=\"title\">${title}</ac:parameter><ac:parameter ac:name=\"type\">pie</ac:parameter><ac:parameter ac:name=\"width\">720</ac:parameter><ac:parameter ac:name=\"height\">460</ac:parameter><ac:parameter ac:name=\"legend\">true</ac:parameter><ac:rich-text-body>${content}</ac:rich-text-body></ac:macro>"
}

GetAttachmentId(){
  local page_id="$1"; local file_name="$2"
  curl --silent --show-error \
    -H "Authorization: Bearer ${CONFLUENCE_TOKEN}" \
    "${CONFLUENCE_BASE_URL}/rest/api/content/${page_id}/child/attachment?filename=${file_name}&expand=version" |
    jq -r '.results[0].id // empty'
}

GetAttachmentDownloadPath(){
  local page_id="$1"; local file_name="$2"
  curl --silent --show-error \
    -H "Authorization: Bearer ${CONFLUENCE_TOKEN}" \
    "${CONFLUENCE_BASE_URL}/rest/api/content/${page_id}/child/attachment?filename=${file_name}&expand=version" |
    jq -r '.results[0]._links.download // empty'
}

DownloadAttachment(){
  local page_id="$1"; local file_name="$2"; local output_file="$3"
  local path
  path=$(GetAttachmentDownloadPath "$page_id" "$file_name")
  [[ -z "$path" ]] && return 1

  curl --silent --show-error --fail \
    -H "Authorization: Bearer ${CONFLUENCE_TOKEN}" \
    "${CONFLUENCE_BASE_URL}${path}" \
    -o "$output_file"
}

UploadFileAndUpdatePage(){
  local page_id="$1"; local file="$2"; local display="${3:-false}"
  local base attachment_id title
  base=$(basename "$file")
  attachment_id=$(GetAttachmentId "$page_id" "$base")

  if [[ -n "$attachment_id" ]]; then
    title=$(curl --silent --show-error \
      -H "Authorization: Bearer ${CONFLUENCE_TOKEN}" \
      -X POST \
      -H "X-Atlassian-Token: nocheck" \
      -F "file=@${file};filename=${base}" \
      "${CONFLUENCE_BASE_URL}/rest/api/content/${page_id}/child/attachment/${attachment_id}/data" |
      jq -r '.title // empty')
  else
    title=$(curl --silent --show-error \
      -H "Authorization: Bearer ${CONFLUENCE_TOKEN}" \
      -X POST \
      -H "X-Atlassian-Token: nocheck" \
      -F "file=@${file};filename=${base}" \
      "${CONFLUENCE_BASE_URL}/rest/api/content/${page_id}/child/attachment" |
      jq -r '.results[0].title // .title // empty')
  fi

  [[ "$title" == "$base" ]] || { LogWarn "Attachment upload/update not confirmed for ${base}"; return 1; }
}
