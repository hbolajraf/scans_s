#!/bin/bash
# =============================================================================
# style.sh
# Shared Confluence-friendly HTML style helpers.
# =============================================================================

source ./scripts/config/config.sh
source ./scripts/common.sh

CreateHtmlStyleFile(){
  mkdir -p "$TMP_DIR"

  cat > "${TMP_DIR}/style.html" <<'HTML'
<style>
.security-report-wrapper {
  font-family: Arial, Helvetica, sans-serif;
  color: #172b4d;
  margin: 10px 0 24px 0;
}

.security-report-title {
  background: #0052cc;
  color: #ffffff;
  padding: 14px 18px;
  border-radius: 8px;
  font-size: 22px;
  font-weight: 700;
  margin: 16px 0;
}

.security-report-subtitle {
  color: #253858;
  border-left: 5px solid #0052cc;
  padding: 8px 12px;
  background: #f4f5f7;
  border-radius: 4px;
  margin: 18px 0 10px 0;
  font-size: 17px;
  font-weight: 700;
}

.security-report-note {
  background: #e6fcff;
  border: 1px solid #79e2f2;
  border-radius: 6px;
  padding: 10px 12px;
  margin: 12px 0;
  color: #0747a6;
}

.security-table {
  width: 100%;
  border-collapse: collapse;
  border: 1px solid #dfe1e6;
  margin: 12px 0 22px 0;
  font-size: 13px;
  box-shadow: 0 1px 3px rgba(9, 30, 66, 0.18);
}

.security-table th {
  background: #0052cc;
  color: #ffffff;
  border: 1px solid #0747a6;
  padding: 9px 10px;
  text-align: center;
  font-weight: 700;
  white-space: nowrap;
}

.security-table td {
  border: 1px solid #dfe1e6;
  padding: 8px 10px;
  text-align: center;
  vertical-align: middle;
}

.security-table tbody tr:nth-child(odd) {
  background: #ffffff;
}

.security-table tbody tr:nth-child(even) {
  background: #f4f5f7;
}

.security-table tbody tr:hover {
  background: #deebff;
}

.security-table td:nth-child(3),
.security-table th:nth-child(3) {
  text-align: left;
}

.report-link {
  color: #0052cc;
  font-weight: 700;
  text-decoration: none;
}

.kpi-positive {
  color: #bf2600;
  font-weight: 700;
}

.kpi-negative {
  color: #006644;
  font-weight: 700;
}

.kpi-neutral {
  color: #42526e;
  font-weight: 700;
}

.delta-up {
  color: #bf2600;
  font-weight: 700;
}

.delta-down {
  color: #006644;
  font-weight: 700;
}

.delta-flat {
  color: #42526e;
  font-weight: 700;
}

.no-data {
  background: #fff7d6;
  border: 1px solid #ffab00;
  color: #974f0c;
  padding: 12px;
  border-radius: 6px;
  font-weight: 700;
  text-align: center;
}

.chart-panel {
  min-height: 460px;
  padding: 12px;
  margin: 16px 0 28px 0;
}

.chart-critical {
  color: #bf2600;
  font-weight: 700;
}

.chart-high {
  color: #ff5630;
  font-weight: 700;
}

.chart-medium {
  color: #ffab00;
  font-weight: 700;
}

.chart-low {
  color: #36b37e;
  font-weight: 700;
}

.chart-total {
  color: #253858;
  font-weight: 700;
}

.dynamic-card {
  border: 1px solid #dfe1e6;
  border-radius: 8px;
  padding: 12px;
  margin: 12px 0;
  background: #ffffff;
}
</style>
HTML
}

WrapHtmlReport(){
  local title="$1"
  local body_file="$2"
  local output_file="$3"

  CreateHtmlStyleFile

  {
    cat "${TMP_DIR}/style.html"
    echo "<div class=\"security-report-wrapper\">"
    echo "<div class=\"security-report-title\">${title}</div>"
    cat "$body_file"
    echo "</div>"
  } > "$output_file"
}
