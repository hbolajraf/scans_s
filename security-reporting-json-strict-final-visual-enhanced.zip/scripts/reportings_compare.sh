#!/bin/bash
source ./scripts/common.sh

CreateDefaultPreviousSecurityJson(){
  cat > "$1" <<'JSON'
{
  "Critical": 0,
  "High": 0,
  "Medium": 0,
  "Low": 0,
  "Total": 0,
  "applications": []
}
JSON
}

CreateDefaultPreviousSonarJson(){
  cat > "$1" <<'JSON'
{
  "Bugs": 0,
  "Vulnerabilities": 0,
  "CodeSmells": 0,
  "Coverage": 0,
  "Duplication": 0,
  "applications": []
}
JSON
}

DeltaClass(){
  local delta="$1"
  awk "BEGIN {
    if (${delta} > 0) print \"kpi-positive\";
    else if (${delta} < 0) print \"kpi-negative\";
    else print \"kpi-neutral\";
  }"
}

CreateSecurityTrendHtml(){
  local previous_json="$1"; local current_json="$2"; local output="$3"; local title="${4:-Evolution sécurité}"
  echo "<div class=\"security-report-subtitle\">${title}</div>" > "$output"
  echo "<table class=\"security-table\"><thead><tr><th>Severity</th><th>Scan précédent</th><th>Dernier scan</th><th>Delta</th></tr></thead><tbody>" >> "$output"

  local k p c d cls
  for k in Critical High Medium Low Total; do
    p=$(JsonNumber "$previous_json" "$k")
    c=$(JsonNumber "$current_json" "$k")
    d=$(awk "BEGIN {print ${c}-${p}}")
    cls=$(DeltaClass "$d")
    echo "<tr><td>${k}</td><td>${p}</td><td>${c}</td><td class=\"${cls}\">${d}</td></tr>" >> "$output"
  done

  echo "</tbody></table>" >> "$output"
}

CreateSonarTrendHtml(){
  local previous_json="$1"; local current_json="$2"; local output="$3"; local title="${4:-Evolution SonarQube}"
  echo "<div class=\"security-report-subtitle\">${title}</div>" > "$output"
  echo "<table class=\"security-table\"><thead><tr><th>KPI</th><th>Scan précédent</th><th>Dernier scan</th><th>Delta</th></tr></thead><tbody>" >> "$output"

  local k p c d cls
  for k in Bugs Vulnerabilities CodeSmells Coverage Duplication; do
    p=$(JsonNumber "$previous_json" "$k")
    c=$(JsonNumber "$current_json" "$k")
    d=$(awk "BEGIN {printf \"%.2f\", ${c}-${p}}")
    cls=$(DeltaClass "$d")
    echo "<tr><td>${k}</td><td>${p}</td><td>${c}</td><td class=\"${cls}\">${d}</td></tr>" >> "$output"
  done

  echo "</tbody></table>" >> "$output"
}

CreateSonarBarChartTable(){
  local previous_json="$1"; local current_json="$2"; local output="$3"
  echo "<table class=\"security-table\"><thead><tr><th>KPI</th><th>Scan précédent</th><th>Dernier scan</th></tr></thead><tbody>" > "$output"

  local k
  for k in Bugs Vulnerabilities CodeSmells Coverage Duplication; do
    echo "<tr><td>${k}</td><td>$(JsonNumber "$previous_json" "$k")</td><td>$(JsonNumber "$current_json" "$k")</td></tr>" >> "$output"
  done

  echo "</tbody></table>" >> "$output"
}


CreateSecurityApplicationTrendHtml(){
  local previous_json="$1"; local current_json="$2"; local output="$3"; local title="${4:-Evolution applicative sécurité}"

  echo "<div class=\"security-report-subtitle\">${title}</div>" > "$output"
  echo "<table class=\"security-table\"><thead><tr><th>Application</th><th>Critical N-1</th><th>Critical N</th><th>High N-1</th><th>High N</th><th>Medium N-1</th><th>Medium N</th><th>Low N-1</th><th>Low N</th><th>Total N-1</th><th>Total N</th><th>Delta Total</th></tr></thead><tbody>" >> "$output"

  jq -r '.applications[]?.name' "$current_json" 2>/dev/null | while read -r app; do
    [[ -z "$app" ]] && continue

    local pC pH pM pL pT cC cH cM cL cT delta cls

    pC=$(jq -r --arg app "$app" '(.applications[]? | select(.name==$app) | .Critical) // 0' "$previous_json" 2>/dev/null)
    pH=$(jq -r --arg app "$app" '(.applications[]? | select(.name==$app) | .High) // 0' "$previous_json" 2>/dev/null)
    pM=$(jq -r --arg app "$app" '(.applications[]? | select(.name==$app) | .Medium) // 0' "$previous_json" 2>/dev/null)
    pL=$(jq -r --arg app "$app" '(.applications[]? | select(.name==$app) | .Low) // 0' "$previous_json" 2>/dev/null)
    pT=$(jq -r --arg app "$app" '(.applications[]? | select(.name==$app) | .Total) // 0' "$previous_json" 2>/dev/null)

    cC=$(jq -r --arg app "$app" '(.applications[]? | select(.name==$app) | .Critical) // 0' "$current_json" 2>/dev/null)
    cH=$(jq -r --arg app "$app" '(.applications[]? | select(.name==$app) | .High) // 0' "$current_json" 2>/dev/null)
    cM=$(jq -r --arg app "$app" '(.applications[]? | select(.name==$app) | .Medium) // 0' "$current_json" 2>/dev/null)
    cL=$(jq -r --arg app "$app" '(.applications[]? | select(.name==$app) | .Low) // 0' "$current_json" 2>/dev/null)
    cT=$(jq -r --arg app "$app" '(.applications[]? | select(.name==$app) | .Total) // 0' "$current_json" 2>/dev/null)

    delta=$(awk "BEGIN {print ${cT}-${pT}}")
    cls=$(DeltaClass "$delta")

    echo "<tr><td>${app}</td><td>${pC}</td><td>${cC}</td><td>${pH}</td><td>${cH}</td><td>${pM}</td><td>${cM}</td><td>${pL}</td><td>${cL}</td><td>${pT}</td><td>${cT}</td><td class=\"${cls}\">${delta}</td></tr>" >> "$output"
  done

  echo "</tbody></table>" >> "$output"
}

CreateSonarApplicationTrendHtml(){
  local previous_json="$1"; local current_json="$2"; local output="$3"; local title="${4:-Evolution applicative SonarQube}"

  echo "<div class=\"security-report-subtitle\">${title}</div>" > "$output"
  echo "<table class=\"security-table\"><thead><tr><th>Application</th><th>Bugs N-1</th><th>Bugs N</th><th>Vulns N-1</th><th>Vulns N</th><th>Code Smells N-1</th><th>Code Smells N</th><th>Coverage N-1</th><th>Coverage N</th><th>Duplication N-1</th><th>Duplication N</th></tr></thead><tbody>" >> "$output"

  jq -r '.applications[]?.name' "$current_json" 2>/dev/null | while read -r app; do
    [[ -z "$app" ]] && continue

    echo "<tr><td>${app}</td><td>$(jq -r --arg app "$app" '(.applications[]? | select(.name==$app) | .Bugs) // 0' "$previous_json" 2>/dev/null)</td><td>$(jq -r --arg app "$app" '(.applications[]? | select(.name==$app) | .Bugs) // 0' "$current_json" 2>/dev/null)</td><td>$(jq -r --arg app "$app" '(.applications[]? | select(.name==$app) | .Vulnerabilities) // 0' "$previous_json" 2>/dev/null)</td><td>$(jq -r --arg app "$app" '(.applications[]? | select(.name==$app) | .Vulnerabilities) // 0' "$current_json" 2>/dev/null)</td><td>$(jq -r --arg app "$app" '(.applications[]? | select(.name==$app) | .CodeSmells) // 0' "$previous_json" 2>/dev/null)</td><td>$(jq -r --arg app "$app" '(.applications[]? | select(.name==$app) | .CodeSmells) // 0' "$current_json" 2>/dev/null)</td><td>$(jq -r --arg app "$app" '(.applications[]? | select(.name==$app) | .Coverage) // 0' "$previous_json" 2>/dev/null)</td><td>$(jq -r --arg app "$app" '(.applications[]? | select(.name==$app) | .Coverage) // 0' "$current_json" 2>/dev/null)</td><td>$(jq -r --arg app "$app" '(.applications[]? | select(.name==$app) | .Duplication) // 0' "$previous_json" 2>/dev/null)</td><td>$(jq -r --arg app "$app" '(.applications[]? | select(.name==$app) | .Duplication) // 0' "$current_json" 2>/dev/null)</td></tr>" >> "$output"
  done

  echo "</tbody></table>" >> "$output"
}


CreateSecurityBarChartTable(){
  local previous_json="$1"
  local current_json="$2"
  local output="$3"

  echo "<table class=\"security-table\"><thead><tr><th>Severity</th><th>Scan précédent</th><th>Dernier scan</th></tr></thead><tbody>" > "$output"

  local k
  for k in Critical High Medium Low Total; do
    echo "<tr><td>${k}</td><td>$(JsonNumber "$previous_json" "$k")</td><td>$(JsonNumber "$current_json" "$k")</td></tr>" >> "$output"
  done

  echo "</tbody></table>" >> "$output"
}



SeverityLabelClass(){
  local key="$1"
  case "$key" in
    Critical) echo "chart-critical" ;;
    High) echo "chart-high" ;;
    Medium) echo "chart-medium" ;;
    Low) echo "chart-low" ;;
    Total) echo "chart-total" ;;
    *) echo "chart-total" ;;
  esac
}

CreateSecurityBarChartTable(){
  local previous_json="$1"
  local current_json="$2"
  local output="$3"

  local total_prev total_curr
  total_prev=$(JsonNumber "$previous_json" "Total")
  total_curr=$(JsonNumber "$current_json" "Total")

  {
    echo "<div class=\"chart-panel\">"
    if [[ "$total_prev" == "0" && "$total_curr" == "0" ]]; then
      echo "<div class=\"no-data\">No Data available</div>"
    fi
    echo "<table class=\"security-table\"><thead><tr><th>Severity</th><th>Scan précédent</th><th>Dernier scan</th></tr></thead><tbody>"

    local k cls
    for k in Critical High Medium Low Total; do
      cls=$(SeverityLabelClass "$k")
      echo "<tr><td class=\"${cls}\">${k}</td><td>$(JsonNumber "$previous_json" "$k")</td><td>$(JsonNumber "$current_json" "$k")</td></tr>"
    done

    echo "</tbody></table>"
    echo "</div>"
  } > "$output"
}

CreateSonarBarChartTable(){
  local previous_json="$1"
  local current_json="$2"
  local output="$3"

  {
    echo "<div class=\"chart-panel\">"
    echo "<table class=\"security-table\"><thead><tr><th>KPI</th><th>Scan précédent</th><th>Dernier scan</th></tr></thead><tbody>"

    local k
    for k in Bugs Vulnerabilities CodeSmells Coverage Duplication; do
      echo "<tr><td>${k}</td><td>$(JsonNumber "$previous_json" "$k")</td><td>$(JsonNumber "$current_json" "$k")</td></tr>"
    done

    echo "</tbody></table>"
    echo "</div>"
  } > "$output"
}

CreateCoveragePieChartTable(){
  local current_json="$1"
  local output="$2"
  local value

  value=$(JsonNumber "$current_json" "Coverage")

  {
    echo "<div class=\"chart-panel\">"
    if [[ "$value" == "0" || "$value" == "0.00" ]]; then
      echo "<div class=\"no-data\">No Data available</div>"
    fi
    echo "<table class=\"security-table\"><thead><tr><th>Coverage</th><th>Yes</th><th>No</th></tr></thead><tbody>"
    echo "<tr><td>Rate</td><td>${value}</td><td>$(awk -v v="$value" 'BEGIN {printf \"%.2f\", 100-v}')</td></tr>"
    echo "</tbody></table>"
    echo "</div>"
  } > "$output"
}

CreateDuplicationPieChartTable(){
  local current_json="$1"
  local output="$2"
  local value

  value=$(JsonNumber "$current_json" "Duplication")

  {
    echo "<div class=\"chart-panel\">"
    if [[ "$value" == "0" || "$value" == "0.00" ]]; then
      echo "<div class=\"no-data\">No Data available</div>"
    fi
    echo "<table class=\"security-table\"><thead><tr><th>Duplications</th><th>KO</th><th>OK</th></tr></thead><tbody>"
    echo "<tr><td>Code</td><td>${value}</td><td>$(awk -v v="$value" 'BEGIN {printf \"%.2f\", 100-v}')</td></tr>"
    echo "</tbody></table>"
    echo "</div>"
  } > "$output"
}
