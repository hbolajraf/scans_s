#!/bin/bash
source ./scripts/config/config.sh
source ./scripts/common.sh
source ./scripts/projects.sh

GenerateSonarqube(){
  local codeAP="$1"
  local branch="$2"
  mkdir -p "$TMP_DIR"
  LogStep "SonarQube generation for ${codeAP}"

  SonarGet(){
    local url="$1"
    local context="$2"
    local response code body

    response=$(curl -sS -w '\n%{http_code}' -u "${SONAR_PAT}:" --location "$url")
    code=$(echo "$response" | tail -1)
    body=$(echo "$response" | sed '$d')

    if ! HttpStatusIsSuccess "$code"; then
      FailIfStrict "${context}: SonarQube API HTTP ${code} - ${url}" || return 1
    fi

    RequireJson "$body" "$context" || return 1
    echo "$body"
  }

  GetMetric(){
    local payload="$1"
    local metric="$2"
    echo "$payload" | jq -r '.component.measures[]? | select(.metric=="'"${metric}"'") | .value' | head -1
  }

  local keys
  keys=$(ValidateIdList sonar $(GetSonarKeys "$codeAP"))

  if [[ -z "$keys" ]]; then
    FailIfStrict "SonarQube: no valid component keys configured for ${codeAP}" || return 1
  fi

  local detail="${TMP_DIR}/reporting_sonarqube_${codeAP}.html"
  local summary="${TMP_DIR}/summary_sonarqube_${codeAP}.html"
  local json="${TMP_DIR}/sonarqube_summary_${codeAP}.json"
  local applications_json="${TMP_DIR}/sonarqube_applications_${codeAP}.json"
  echo '{"tool":"sonarqube","applications":[]}' > "$applications_json"

  echo "<div class="security-report-subtitle">SonarQube</div><table class="security-table"><thead><tr><th>Date</th><th>Branche</th><th>Application</th><th>Bugs N-1</th><th>Bugs N</th><th>Δ Bugs</th><th>Vulnerabilities N-1</th><th>Vulnerabilities N</th><th>Δ Vulnerabilities</th><th>Code Smells N-1</th><th>Code Smells N</th><th>Δ Code Smells</th><th>Lignes de code</th><th>Coverage N-1</th><th>Coverage N</th><th>Δ Coverage</th><th>Duplication N-1</th><th>Duplication N</th><th>Δ Duplication</th><th>Lien</th></tr></thead><tbody>" > "$detail"

  local sumB=0 sumV=0 sumS=0 totalNcloc=0 weightedCoverage=0 weightedDup=0
  local key measures analyses date bugs vulns smells ncloc coverage dup metrics

  metrics="bugs,vulnerabilities,code_smells,coverage,duplicated_lines_density,ncloc"

  for key in $keys; do
    measures=$(SonarGet "${SONAR_BASE_URL}/api/measures/component?branch=${branch}&component=${key}&metricKeys=${metrics}" "Sonar measures for ${key}") || true

    if [[ -z "$measures" ]] || echo "$measures" | jq -e '.errors' >/dev/null 2>&1; then
      LogWarn "SonarQube: no report found for ${key} on branch ${branch}; falling back to latest/default branch"
      measures=$(SonarGet "${SONAR_BASE_URL}/api/measures/component?component=${key}&metricKeys=${metrics}" "Sonar default/latest measures for ${key}") || {
        LogWarn "SonarQube: no report found for ${key}; continuing"
        echo "<tr><td>-</td><td>${branch}</td><td>${key}</td><td colspan=\"16\">Pas de rapport</td><td><a href=\"${SONAR_BASE_URL}/dashboard?id=${key}\" target=\"_blank\">Projet</a></td></tr>" >> "$detail"
        continue
      }
    fi

    if echo "$measures" | jq -e '.errors' >/dev/null 2>&1; then
      FailIfStrict "SonarQube returned errors for ${key}: $(echo "$measures" | jq -c '.errors')" || return 1
    fi

    analyses=$(SonarGet "${SONAR_BASE_URL}/api/project_analyses/search?project=${key}" "Sonar analyses for ${key}") || return 1
    date=$(echo "$analyses" | jq -r '.analyses[0].date // "-"')

    bugs=$(GetMetric "$measures" "bugs"); bugs=${bugs:-0}
    vulns=$(GetMetric "$measures" "vulnerabilities"); vulns=${vulns:-0}
    smells=$(GetMetric "$measures" "code_smells"); smells=${smells:-0}
    ncloc=$(GetMetric "$measures" "ncloc"); ncloc=${ncloc:-0}
    coverage=$(GetMetric "$measures" "coverage"); coverage=${coverage:-0}
    dup=$(GetMetric "$measures" "duplicated_lines_density"); dup=${dup:-0}

    
    pB=$(PreviousSonarValue "$codeAP" "$key" "Bugs")
    pV=$(PreviousSonarValue "$codeAP" "$key" "Vulnerabilities")
    pS=$(PreviousSonarValue "$codeAP" "$key" "CodeSmells")
    pCov=$(PreviousSonarValue "$codeAP" "$key" "Coverage")
    pDup=$(PreviousSonarValue "$codeAP" "$key" "Duplication")

    dB=$(DeltaValue "$bugs" "$pB")
    dV=$(DeltaValue "$vulns" "$pV")
    dS=$(DeltaValue "$smells" "$pS")
    dCov=$(DeltaValue "$coverage" "$pCov")
    dDup=$(DeltaValue "$dup" "$pDup")

    clsB=$(DeltaClass "$dB")
    clsV=$(DeltaClass "$dV")
    clsS=$(DeltaClass "$dS")
    clsCov=$(DeltaClass "$dCov")
    clsDup=$(DeltaClass "$dDup")

    sumB=$((sumB+bugs))
    sumV=$((sumV+vulns))
    sumS=$((sumS+smells))
    totalNcloc=$((totalNcloc+ncloc))
    weightedCoverage=$(awk "BEGIN {print ${weightedCoverage}+(${coverage}*${ncloc})}")
    weightedDup=$(awk "BEGIN {print ${weightedDup}+(${dup}*${ncloc})}")

    echo "<tr><td>${date}</td><td>${branch}</td><td>${key}</td><td>${pB}</td><td>${bugs}</td><td class=\"${clsB}\">${dB}</td><td>${pV}</td><td>${vulns}</td><td class=\"${clsV}\">${dV}</td><td>${pS}</td><td>${smells}</td><td class=\"${clsS}\">${dS}</td><td>${ncloc}</td><td>${pCov}</td><td>${coverage}%</td><td class=\"${clsCov}\">${dCov}</td><td>${pDup}</td><td>${dup}%</td><td class=\"${clsDup}\">${dDup}</td><td><a href=\"${SONAR_BASE_URL}/dashboard?id=${key}\" target=\"_blank\">Rapport</a></td></tr>" >> "$detail"

    local sonar_branch="${effectiveBranch:-$branch}"
    local app_file="${TMP_DIR}/sonarqube_$(SafeFileName "$codeAP")_$(SafeFileName "$key").json"
    jq -n \
      --arg tool "sonarqube" \
      --arg code_ap "$codeAP" \
      --arg name "$key" \
      --arg branch "$sonar_branch" \
      --arg date "$date" \
      --arg url "${SONAR_BASE_URL}/dashboard?id=${key}" \
      --argjson Bugs "$bugs" \
      --argjson Vulnerabilities "$vulns" \
      --argjson CodeSmells "$smells" \
      --argjson Coverage "$coverage" \
      --argjson Duplication "$dup" \
      --argjson Ncloc "$ncloc" \
      '{tool:$tool, code_ap:$code_ap, name:$name, branch:$branch, date:$date, url:$url, Bugs:$Bugs, Vulnerabilities:$Vulnerabilities, CodeSmells:$CodeSmells, Coverage:$Coverage, Duplication:$Duplication, Ncloc:$Ncloc}' > "$app_file"

    jq --slurpfile app "$app_file" '.applications += [$app[0]]' "$applications_json" > "${applications_json}.tmp" && mv "${applications_json}.tmp" "$applications_json"

  done

  echo "</tbody></table>" >> "$detail"

  local globalCoverage=0 globalDup=0
  if [[ "$totalNcloc" -gt 0 ]]; then
    globalCoverage=$(awk "BEGIN {printf \"%.2f\", ${weightedCoverage}/${totalNcloc}}")
    globalDup=$(awk "BEGIN {printf \"%.2f\", ${weightedDup}/${totalNcloc}}")
  fi

  cat > "$summary" <<HTML
<table class="security-table"><thead><tr><th>Level</th><th>Count</th></tr></thead><tbody>
<tr><td>Bugs</td><td>${sumB}</td></tr>
<tr><td>Vulnerabilities</td><td>${sumV}</td></tr>
<tr><td>Code Smells</td><td>${sumS}</td></tr>
<tr><td>Coverage</td><td>${globalCoverage}</td></tr>
<tr><td>Duplication</td><td>${globalDup}</td></tr>
</tbody></table>
HTML

  cat > "${TMP_DIR}/summary_sonarqube_coverage_${codeAP}.html" <<HTML
<table class="security-table"><thead><tr><th>Coverage</th><th>Yes</th><th>No</th></tr></thead><tbody>
<tr><td>Rate</td><td>${globalCoverage}</td><td>$(awk "BEGIN {printf \"%.2f\", 100-${globalCoverage}}")</td></tr>
</tbody></table>
HTML

  cat > "${TMP_DIR}/summary_sonarqube_duplication_${codeAP}.html" <<HTML
<table class="security-table"><thead><tr><th>Duplications</th><th>KO</th><th>OK</th></tr></thead><tbody>
<tr><td>Code</td><td>${globalDup}</td><td>$(awk "BEGIN {printf \"%.2f\", 100-${globalDup}}")</td></tr>
</tbody></table>
HTML

  cat > "$json" <<JSON
{
  "Bugs": ${sumB},
  "Vulnerabilities": ${sumV},
  "CodeSmells": ${sumS},
  "Coverage": ${globalCoverage},
  "Duplication": ${globalDup},
  "applications": $(jq -c '.applications' "$applications_json")
}
JSON

  LogInfo "SonarQube totals for ${codeAP}: Bugs=${sumB}, Vulns=${sumV}, Smells=${sumS}, Coverage=${globalCoverage}, Dup=${globalDup}"
}
