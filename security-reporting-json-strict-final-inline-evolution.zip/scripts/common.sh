#!/bin/bash
# =============================================================================
# common.sh
# Shared utilities.
# All logs go to stderr to keep stdout clean for function return values.
# =============================================================================

set -o pipefail

_LOG_TS(){ date '+%F %T'; }

LogDebug(){ [[ "${LOG_LEVEL:-INFO}" == "DEBUG" ]] && echo "[$(_LOG_TS)] DEBUG $*" >&2; }
LogInfo(){ echo "[$(_LOG_TS)] INFO  $*" >&2; }
LogWarn(){ echo "[$(_LOG_TS)] WARN  $*" >&2; }
LogError(){ echo "[$(_LOG_TS)] ERROR $*" >&2; }
LogStep(){ echo "" >&2; echo "[$(_LOG_TS)] STEP  $*" >&2; }

EnsureCommand(){
  local command_name="$1"
  if ! command -v "$command_name" >/dev/null 2>&1; then
    LogError "Missing required command: ${command_name}"
    return 1
  fi
}

EnsurePrerequisites(){
  LogStep "Checking prerequisites"
  EnsureCommand bash
  EnsureCommand curl
  EnsureCommand jq
  EnsureCommand sed
  EnsureCommand awk
  EnsureCommand bc
  EnsureCommand unzip
  LogInfo "Prerequisites OK"
}

CreateWorkDir(){
  mkdir -p "$WORK_DIR" "$TMP_DIR"
}

HttpStatusIsSuccess(){
  local code="$1"
  [[ "$code" =~ ^[0-9]+$ ]] && (( code >= 200 && code <= 299 ))
}

JsonNumber(){
  local file="$1"
  local key="$2"
  if [[ ! -f "$file" ]]; then
    echo "0"
    return 0
  fi
  jq -r "(.${key} // 0)" "$file" 2>/dev/null | awk '{ if ($0 == "" || $0 == "null") print 0; else print $0 }'
}

CleanupGeneratedFiles(){
  mkdir -p "${TMP_DIR:-./tmp}"
  rm -rf "${TMP_DIR:?}/"* || true
}

RequireJson(){
  local json="$1"
  local context="$2"

  if [[ -z "$json" ]]; then
    LogError "${context}: empty API response"
    return 1
  fi

  echo "$json" | jq empty >/dev/null 2>&1 || {
    LogError "${context}: invalid JSON response"
    LogError "Payload preview: $(echo "$json" | head -c 500)"
    return 1
  }
}

RequireNonEmpty(){
  local value="$1"
  local context="$2"

  if [[ -z "$value" || "$value" == "null" ]]; then
    LogError "${context}: missing mandatory value"
    return 1
  fi
}

FailIfStrict(){
  local message="$1"
  if [[ "${STRICT_REPORTING:-true}" == "true" ]]; then
    LogError "$message"
    return 1
  else
    LogWarn "$message"
  fi
}

SafeFileName(){
  local value="$1"
  echo "$value" | sed 's/[^A-Za-z0-9._-]/_/g'
}

DeltaClass(){
  local delta="$1"
  awk -v d="$delta" 'BEGIN { if (d > 0) print "kpi-positive"; else if (d < 0) print "kpi-negative"; else print "kpi-neutral"; }'
}

DeltaValue(){
  local current="$1"
  local previous="$2"
  awk -v c="$current" -v p="$previous" 'BEGIN { printf "%.2f", c-p }'
}

PreviousSecurityValue(){
  local tool="$1"
  local codeAP="$2"
  local app="$3"
  local key="$4"
  local file="${TMP_DIR}/${tool}_previous_${codeAP}.json"

  if [[ ! -f "$file" ]]; then
    echo 0
    return 0
  fi

  jq -r --arg app "$app" --arg key "$key" '(.applications[]? | select(.name==$app) | .[$key]) // 0' "$file" 2>/dev/null
}

PreviousSonarValue(){
  local codeAP="$1"
  local app="$2"
  local key="$3"
  local file="${TMP_DIR}/sonarqube_previous_${codeAP}.json"

  if [[ ! -f "$file" ]]; then
    echo 0
    return 0
  fi

  jq -r --arg app "$app" --arg key "$key" '(.applications[]? | select(.name==$app) | .[$key]) // 0' "$file" 2>/dev/null
}
