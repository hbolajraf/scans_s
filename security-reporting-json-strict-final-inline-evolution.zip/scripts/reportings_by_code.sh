#!/bin/bash
set -euo pipefail

source ./scripts/config/config.sh
source ./scripts/common.sh
source ./scripts/projects.sh
source ./scripts/confluence.sh
source ./scripts/style.sh
source ./scripts/reportings_compare.sh
source ./scripts/reportings_fortify.sh
source ./scripts/reportings_nexus.sh
source ./scripts/reportings_sonarqube.sh
source ./scripts/reportings_sysdig.sh

PreparePreviousJson(){
  local history_page_id="$1"
  local attachment="$2"
  local output="$3"
  local type="$4"

  mkdir -p "$TMP_DIR"

  if DownloadAttachment "$history_page_id" "$attachment" "$output"; then
    LogInfo "Previous JSON found: ${attachment}"
  else
    LogInfo "Previous JSON unavailable, probably first run: ${attachment}"
    if [[ "$type" == "sonar" ]]; then
      CreateDefaultPreviousSonarJson "$output"
    else
      CreateDefaultPreviousSecurityJson "$output"
    fi
  fi
}

PrepareAllPreviousJson(){
  local history_page="$1"
  local codeAP="$2"

  PreparePreviousJson "$history_page" "fortify_summary_${codeAP}.json" "${TMP_DIR}/fortify_previous_${codeAP}.json" "security"
  PreparePreviousJson "$history_page" "nexus_summary_${codeAP}.json" "${TMP_DIR}/nexus_previous_${codeAP}.json" "security"
  PreparePreviousJson "$history_page" "sysdig_summary_${codeAP}.json" "${TMP_DIR}/sysdig_previous_${codeAP}.json" "security"
  PreparePreviousJson "$history_page" "sonarqube_summary_${codeAP}.json" "${TMP_DIR}/sonarqube_previous_${codeAP}.json" "sonar"
}

AssertGeneratedFile(){
  local file="$1"
  if [[ ! -f "$file" ]]; then
    LogError "Expected generated file not found: ${file}"
    return 1
  fi
}

UploadToolApplicationJsonFiles(){
  local history_page="$1"
  local tool="$2"
  local codeAP="$3"

  local f
  for f in "${TMP_DIR}/${tool}_${codeAP}_"*.json; do
    [[ -f "$f" ]] || continue
    UploadFileAndUpdatePage "$history_page" "$f" false || LogWarn "Could not upload application JSON: $f"
  done
}

UploadCurrentToolJsonFiles(){
  local history_page="$1"
  local codeAP="$2"

  UploadFileAndUpdatePage "$history_page" "${TMP_DIR}/fortify_summary_${codeAP}.json" false
  UploadFileAndUpdatePage "$history_page" "${TMP_DIR}/nexus_summary_${codeAP}.json" false
  UploadFileAndUpdatePage "$history_page" "${TMP_DIR}/sysdig_summary_${codeAP}.json" false
  UploadFileAndUpdatePage "$history_page" "${TMP_DIR}/sonarqube_summary_${codeAP}.json" false

  UploadToolApplicationJsonFiles "$history_page" "fortify" "$codeAP"
  UploadToolApplicationJsonFiles "$history_page" "nexus" "$codeAP"
  UploadToolApplicationJsonFiles "$history_page" "sysdig" "$codeAP"
  UploadToolApplicationJsonFiles "$history_page" "sonarqube" "$codeAP"
}

GenerateCombinedApplicationHistoryFiles(){
  local codeAP="$1"
  local history_page="$2"
  local apps_file="${TMP_DIR}/applications_${codeAP}.list"

  : > "$apps_file"

  for file in \
    "${TMP_DIR}/fortify_summary_${codeAP}.json" \
    "${TMP_DIR}/nexus_summary_${codeAP}.json" \
    "${TMP_DIR}/sysdig_summary_${codeAP}.json" \
    "${TMP_DIR}/sonarqube_summary_${codeAP}.json"; do
    [[ -f "$file" ]] || continue
    jq -r '.applications[]?.name' "$file" 2>/dev/null >> "$apps_file" || true
  done

  sort -u "$apps_file" -o "$apps_file"

  local app safe output
  while IFS= read -r app; do
    [[ -z "$app" ]] && continue
    safe=$(SafeFileName "$app")
    output="${TMP_DIR}/history_${codeAP}_${safe}.json"

    jq -n \
      --arg code_ap "$codeAP" \
      --arg application "$app" \
      --slurpfile fp "${TMP_DIR}/fortify_previous_${codeAP}.json" \
      --slurpfile fc "${TMP_DIR}/fortify_summary_${codeAP}.json" \
      --slurpfile np "${TMP_DIR}/nexus_previous_${codeAP}.json" \
      --slurpfile nc "${TMP_DIR}/nexus_summary_${codeAP}.json" \
      --slurpfile sp "${TMP_DIR}/sysdig_previous_${codeAP}.json" \
      --slurpfile sc "${TMP_DIR}/sysdig_summary_${codeAP}.json" \
      --slurpfile qp "${TMP_DIR}/sonarqube_previous_${codeAP}.json" \
      --slurpfile qc "${TMP_DIR}/sonarqube_summary_${codeAP}.json" \
      'def appvals($x): (($x[0].applications // [])[]? | select(.name==$application)) // {};
       {
         code_ap: $code_ap,
         application: $application,
         previous: {
           fortify: appvals($fp),
           nexus: appvals($np),
           sysdig: appvals($sp),
           sonarqube: appvals($qp)
         },
         current: {
           fortify: appvals($fc),
           nexus: appvals($nc),
           sysdig: appvals($sc),
           sonarqube: appvals($qc)
         }
       }' > "$output"

    UploadFileAndUpdatePage "$history_page" "$output" false || LogWarn "Could not upload application history JSON: $output"
  done < "$apps_file"
}

CreateSummaryEvolutionCharts(){
  local page_summary="$1"
  local codeAP="$2"

  local chart

  chart="${TMP_DIR}/chart_sysdig_evolution_${codeAP}.html"
  CreateSecurityBarChartTable "${TMP_DIR}/sysdig_previous_${codeAP}.json" "${TMP_DIR}/sysdig_summary_${codeAP}.json" "$chart"
  UpdatePageWithBarChartMacro "$page_summary" "$chart" "Sysdig - Evolution N-1 / N"

  chart="${TMP_DIR}/chart_nexus_evolution_${codeAP}.html"
  CreateSecurityBarChartTable "${TMP_DIR}/nexus_previous_${codeAP}.json" "${TMP_DIR}/nexus_summary_${codeAP}.json" "$chart"
  UpdatePageWithBarChartMacro "$page_summary" "$chart" "Nexus IQ - Evolution N-1 / N"

  chart="${TMP_DIR}/chart_fortify_evolution_${codeAP}.html"
  CreateSecurityBarChartTable "${TMP_DIR}/fortify_previous_${codeAP}.json" "${TMP_DIR}/fortify_summary_${codeAP}.json" "$chart"
  UpdatePageWithBarChartMacro "$page_summary" "$chart" "Fortify - Evolution N-1 / N"

  chart="${TMP_DIR}/chart_sonarqube_evolution_${codeAP}.html"
  CreateSonarBarChartTable "${TMP_DIR}/sonarqube_previous_${codeAP}.json" "${TMP_DIR}/sonarqube_summary_${codeAP}.json" "$chart"
  UpdatePageWithBarChartMacro "$page_summary" "$chart" "SonarQube - Evolution N-1 / N"
}

GenerateReportsForCodeAP(){
  local codeAP="$1"

  ValidateProjectConfig "$codeAP"
  mkdir -p "$WORK_DIR" "$TMP_DIR"
  CreateHtmlStyleFile

  local name parent page_detail page_summary page_root now merged_body merged_report
  name=$(GetProjectName "$codeAP")
  parent=$(GetConfluencePage "$codeAP")
  now="${CI_SSR_DATE:-$(date '+%F_%T')}"
  merged_body="${TMP_DIR}/reporting_${name}_body.html"
  merged_report="${TMP_DIR}/reporting_${name}.html"

  LogStep "Generating complete report for ${name} (${codeAP})"

  # Previous JSON must be available before building the main tables.
  PrepareAllPreviousJson "$parent" "$codeAP"

  GenerateFortity "$codeAP" "$REPORT_BRANCH"
  GenerateNexus "$codeAP"
  GenerateSonarqube "$codeAP" "$REPORT_BRANCH"
  GenerateSysdig "$codeAP"

  AssertGeneratedFile "${TMP_DIR}/reporting_fortify_${codeAP}.html"
  AssertGeneratedFile "${TMP_DIR}/reporting_nexus_${codeAP}.html"
  AssertGeneratedFile "${TMP_DIR}/reporting_sonarqube_${codeAP}.html"
  AssertGeneratedFile "${TMP_DIR}/reporting_sysdig_${codeAP}.html"

  cat "${TMP_DIR}/reporting_fortify_${codeAP}.html" \
      "${TMP_DIR}/reporting_nexus_${codeAP}.html" \
      "${TMP_DIR}/reporting_sonarqube_${codeAP}.html" \
      "${TMP_DIR}/reporting_sysdig_${codeAP}.html" \
      > "$merged_body"

  WrapHtmlReport "Rapport détaillé - ${name} (${codeAP})" "$merged_body" "$merged_report"

  page_root=$(CreatePage "${now}-${name}" "<h1>Rapport des scans de sécurité - ${name}</h1><p>Rapport généré automatiquement par GitLab CI.</p>" "$parent" "$CONFLUENCE_SPACE")
  page_detail=$(CreatePage "${now}-${name}-Détail" "<h1>Détail des scans</h1>" "$page_root" "$CONFLUENCE_SPACE")
  page_summary=$(CreatePage "${now}-${name}-Synthèse" "<h1>Synthèse des scans</h1>" "$page_root" "$CONFLUENCE_SPACE")

  UpdatePageWithHtmlContent "$page_detail" "$(cat "$merged_report")"

  UpdatePageWithHtmlContent "$page_summary" "$(cat "${TMP_DIR}/style.html")"
  CreateSummaryEvolutionCharts "$page_summary" "$codeAP"

  UploadCurrentToolJsonFiles "$parent" "$codeAP"
  GenerateCombinedApplicationHistoryFiles "$codeAP" "$parent"
}

main(){
  EnsurePrerequisites
  CreateWorkDir

  local codes="${REPORT_CODE_APS:-$(GetConfiguredCodeAPs)}"
  local codeAP

  for codeAP in $codes; do
    GenerateReportsForCodeAP "$codeAP"
  done
}

main "$@"
