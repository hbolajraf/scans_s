#!/bin/bash
source ./scripts/config/config.sh
source ./scripts/common.sh
source ./scripts/projects.sh

GenerateNexus(){
  local codeAP="$1"
  mkdir -p "$TMP_DIR"
  LogStep "Nexus generation for ${codeAP}"

  NexusGet(){
    local url="$1"
    local context="$2"
    local response code body

    response=$(curl -sS -w '\n%{http_code}' -u "${NEXUS_USER}:${NEXUS_PAT}" --location "$url")
    code=$(echo "$response" | tail -1)
    body=$(echo "$response" | sed '$d')

    if ! HttpStatusIsSuccess "$code"; then
      FailIfStrict "${context}: Nexus API HTTP ${code} - ${url}" || return 1
    fi

    RequireJson "$body" "$context" || return 1
    echo "$body"
  }

  GetDiscoveredIds(){
    local payload
    payload=$(NexusGet "${NEXUS_BASE_URL}/api/v2/applications" "Nexus applications list") || return 1
    echo "$payload" | jq -r '.applications[]? | select(.name | contains("'"${codeAP}"'")) | .id'
  }

  GetAppName(){
    local appId="$1"
    local payload
    payload=$(NexusGet "${NEXUS_BASE_URL}/api/v2/applications/${appId}" "Nexus application ${appId}") || return 1
    echo "$payload" | jq -r '.name // empty'
  }

  GetReportHistory(){
    local appId="$1"
    NexusGet "${NEXUS_BASE_URL}/api/v2/reports/applications/${appId}/history?limit=25" "Nexus report history for ${appId}"
  }

  SelectReportForApplication(){
    local app="$1"
    local history="$2"

    if [[ "$app" == *"_nuget"* ]]; then
      LogInfo "Nexus: ${app} contains _nuget, selecting develop report instead of default/latest"
      echo "$history" | jq -c '.reports[]? | select((.stage // .branch // .reportDataUrl // "") | tostring | contains("develop"))' | head -1
    else
      echo "$history" | jq -c '.reports[0] // empty'
    fi
  }

  local ids
  ids=$(ApplyIncludeOnly "$(GetDiscoveredIds)" "$(GetNexusInclude "$codeAP")" "nexus")

  if [[ -z "$ids" ]]; then
    LogWarn "Nexus: no valid application IDs found for ${codeAP}; continuing with empty Nexus report"
  fi

  local detail="${TMP_DIR}/reporting_nexus_${codeAP}.html"
  local summary="${TMP_DIR}/summary_nexus_${codeAP}.html"
  local json="${TMP_DIR}/nexus_summary_${codeAP}.json"
  local applications_json="${TMP_DIR}/nexus_applications_${codeAP}.json"
  echo '{"tool":"nexus","applications":[]}' > "$applications_json"

  echo "<div class="security-report-subtitle">Nexus IQ</div><table class="security-table"><thead><tr><th>Date</th><th>Stage/Branche</th><th>Application</th><th>Critical N-1</th><th>Critical N</th><th>Δ Critical</th><th>High N-1</th><th>High N</th><th>Δ High</th><th>Medium N-1</th><th>Medium N</th><th>Δ Medium</th><th>Low N-1</th><th>Low N</th><th>Δ Low</th><th>Total N-1</th><th>Total N</th><th>Δ Total</th><th>Lien Nexus</th></tr></thead><tbody>" > "$detail"

  local sumC=0 sumH=0 sumM=0 sumL=0
  local id app history report date stage c h m l total link

  for id in $ids; do
    app=$(GetAppName "$id") || return 1
    if [[ -z "$app" || "$app" == "null" ]]; then
      LogWarn "Nexus: application name not found for ${id}; continuing"
      echo "<tr><td>-</td><td>-</td><td>${id}</td><td colspan=\"15\">Pas de rapport</td><td>-</td></tr>" >> "$detail"
      continue
    fi

    history=$(GetReportHistory "$id") || return 1
    report=$(SelectReportForApplication "$app" "$history")

    if [[ -z "$report" || "$report" == "null" ]]; then
      if [[ "$app" == *"_nuget"* ]]; then
        LogWarn "Nexus: no develop report found for _nuget application ${app}; continuing"
        echo "<tr><td>-</td><td>develop</td><td>${app}</td><td colspan=\"15\">Pas de rapport</td><td>-</td></tr>" >> "$detail"
      else
        LogWarn "Nexus: no report found for ${app}; continuing"
        echo "<tr><td>-</td><td>-</td><td>${app}</td><td colspan=\"15\">Pas de rapport</td><td>-</td></tr>" >> "$detail"
      fi
      continue
    fi

    date=$(echo "$report" | jq -r '.evaluationDate // "-"')
    stage=$(echo "$report" | jq -r '.stage // .branch // "-"')
    c=$(echo "$report" | jq -r '.policyEvaluationResult.criticalPolicyViolationCount // 0')
    h=$(echo "$report" | jq -r '.policyEvaluationResult.severePolicyViolationCount // 0')
    m=$(echo "$report" | jq -r '.policyEvaluationResult.moderatePolicyViolationCount // 0')
    l=0
    total=$((c+h+m+l))
    link=$(echo "$report" | jq -r '.latestReportHtmlUrl // ""')

    
    pC=$(PreviousSecurityValue "nexus" "$codeAP" "$app" "Critical")
    pH=$(PreviousSecurityValue "nexus" "$codeAP" "$app" "High")
    pM=$(PreviousSecurityValue "nexus" "$codeAP" "$app" "Medium")
    pL=$(PreviousSecurityValue "nexus" "$codeAP" "$app" "Low")
    pT=$(PreviousSecurityValue "nexus" "$codeAP" "$app" "Total")

    dC=$(DeltaValue "$c" "$pC")
    dH=$(DeltaValue "$h" "$pH")
    dM=$(DeltaValue "$m" "$pM")
    dL=$(DeltaValue "$l" "$pL")
    dT=$(DeltaValue "$total" "$pT")

    clsC=$(DeltaClass "$dC")
    clsH=$(DeltaClass "$dH")
    clsM=$(DeltaClass "$dM")
    clsL=$(DeltaClass "$dL")
    clsT=$(DeltaClass "$dT")

    sumC=$((sumC+c))
    sumH=$((sumH+h))
    sumM=$((sumM+m))
    sumL=$((sumL+l))

    echo "<tr><td>${date}</td><td>${stage}</td><td>${app}</td><td>${pC}</td><td>${c}</td><td class=\"${clsC}\">${dC}</td><td>${pH}</td><td>${h}</td><td class=\"${clsH}\">${dH}</td><td>${pM}</td><td>${m}</td><td class=\"${clsM}\">${dM}</td><td>${pL}</td><td>${l}</td><td class=\"${clsL}\">${dL}</td><td>${pT}</td><td>${total}</td><td class=\"${clsT}\">${dT}</td><td><a href=\"${NEXUS_BASE_URL}/${link}\" target=\"_blank\">Rapport</a></td></tr>" >> "$detail"

    local app_file="${TMP_DIR}/nexus_$(SafeFileName "$codeAP")_$(SafeFileName "$app").json"
    jq -n \
      --arg tool "nexus" \
      --arg code_ap "$codeAP" \
      --arg name "$app" \
      --arg branch "$stage" \
      --arg date "$date" \
      --arg url "${NEXUS_BASE_URL}/${link}" \
      --argjson Critical "$c" \
      --argjson High "$h" \
      --argjson Medium "$m" \
      --argjson Low "$l" \
      --argjson Total "$total" \
      '{tool:$tool, code_ap:$code_ap, name:$name, branch:$branch, date:$date, url:$url, Critical:$Critical, High:$High, Medium:$Medium, Low:$Low, Total:$Total}' > "$app_file"

    jq --slurpfile app "$app_file" '.applications += [$app[0]]' "$applications_json" > "${applications_json}.tmp" && mv "${applications_json}.tmp" "$applications_json"

  done

  echo "</tbody></table>" >> "$detail"

  local sumT=$((sumC+sumH+sumM+sumL))
  cat > "$summary" <<HTML
<table class="security-table"><thead><tr><th>Level</th><th>Count</th></tr></thead><tbody>
<tr><td>Critical</td><td>${sumC}</td></tr>
<tr><td>High</td><td>${sumH}</td></tr>
<tr><td>Medium</td><td>${sumM}</td></tr>
<tr><td>Low</td><td>${sumL}</td></tr>
<tr><td>Total</td><td>${sumT}</td></tr>
</tbody></table>
HTML

  cat > "$json" <<JSON
{
  "Critical": ${sumC},
  "High": ${sumH},
  "Medium": ${sumM},
  "Low": ${sumL},
  "Total": ${sumT},
  "applications": $(jq -c '.applications' "$applications_json")
}
JSON

  LogInfo "Nexus totals for ${codeAP}: C=${sumC}, H=${sumH}, M=${sumM}, L=${sumL}, T=${sumT}"
}
