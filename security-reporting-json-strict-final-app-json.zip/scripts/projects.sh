#!/bin/bash
# =============================================================================
# projects.sh
# JSON-based project registry loader.
# =============================================================================

source ./scripts/config/config.sh
source ./scripts/common.sh

GetProjectFile(){
  local codeAP="$1"
  echo "${PROJECTS_DIR}/${codeAP}.json"
}

ProjectExists(){
  local codeAP="$1"
  [[ -f "$(GetProjectFile "$codeAP")" ]]
}

IsSafeCodeAP(){ [[ "$1" =~ ^AP[0-9]{5}$ ]]; }
IsSafeNumericId(){ [[ "$1" =~ ^[0-9]+$ ]]; }
IsSafeNexusId(){ [[ "$1" =~ ^[A-Za-z0-9_-]+$ ]]; }
IsSafeSonarKey(){ [[ "$1" =~ ^[A-Za-z0-9_.:-]+$ ]]; }


ValidateIdList(){
  local id_type="$1"
  shift || true

  local value
  local result=()

  for value in "$@"; do
    [[ -z "${value:-}" ]] && continue

    case "$id_type" in
      numeric)
        if ! IsSafeNumericId "$value"; then
          LogWarn "Rejected unsafe numeric ID: ${value}"
          continue
        fi
        ;;
      nexus)
        if ! IsSafeNexusId "$value"; then
          LogWarn "Rejected unsafe Nexus ID: ${value}"
          continue
        fi
        ;;
      sonar)
        if ! IsSafeSonarKey "$value"; then
          LogWarn "Rejected unsafe Sonar key: ${value}"
          continue
        fi
        ;;
      *)
        LogError "Unknown validation type: ${id_type}"
        return 1
        ;;
    esac

    #
    # FIX:
    # Avoid:
    #   result[@]: unbound variable
    #
    # when using:
    #   set -u
    #
    # Bash throws an error if an empty array is expanded.
    #
    if [[ "${#result[@]}" -eq 0 ]]; then
      result+=("$value")
      continue
    fi

    local already_exists="false"
    local existing

    for existing in "${result[@]}"; do
      if [[ "$existing" == "$value" ]]; then
        already_exists="true"
        break
      fi
    done

    if [[ "$already_exists" == "false" ]]; then
      result+=("$value")
    fi
  done

  #
  # Print validated unique values safely.
  #
  if [[ "${#result[@]}" -gt 0 ]]; then
    printf '%s\n' "${result[@]}"
  fi
}

ValidateProjectFile(){
  local codeAP="$1"
  local file
  file=$(GetProjectFile "$codeAP")

  IsSafeCodeAP "$codeAP" || { LogError "Unsafe Code AP: ${codeAP}"; return 1; }

  [[ -f "$file" ]] || { LogError "Project file not found: ${file}"; return 1; }

  jq empty "$file" >/dev/null 2>&1 || { LogError "Invalid JSON: ${file}"; return 1; }

  [[ "$(jq -r '.code_ap' "$file")" == "$codeAP" ]] || {
    LogError "JSON code_ap does not match filename for ${file}"
    return 1
  }

  local page
  page=$(jq -r '.confluence_page' "$file")
  IsSafeNumericId "$page" || { LogError "Unsafe Confluence page ID: ${page}"; return 1; }

  jq -e '.name and .confluence_page and (.gitlab_ids|type=="array") and (.sonar_keys|type=="array") and (.fortify_include|type=="array") and (.nexus_include|type=="array")' "$file" >/dev/null || {
    LogError "Missing mandatory fields in ${file}"
    return 1
  }

  LogInfo "Validated project file: ${file}"
}

GetConfiguredCodeAPs(){
  find "$PROJECTS_DIR" -name '*.json' -exec basename {} .json \; | sort
}

GetProjectName(){ jq -r '.name' "$(GetProjectFile "$1")"; }
GetConfluencePage(){ jq -r '.confluence_page' "$(GetProjectFile "$1")"; }
GetFortifyInclude(){ jq -r '.fortify_include[]?' "$(GetProjectFile "$1")"; }
GetNexusInclude(){ jq -r '.nexus_include[]?' "$(GetProjectFile "$1")"; }
GetGitlabIds(){ jq -r '.gitlab_ids[]?' "$(GetProjectFile "$1")"; }
GetSonarKeys(){ jq -r '.sonar_keys[]?' "$(GetProjectFile "$1")"; }

ApplyIncludeOnly(){
  local discovered_values="$1"
  local include_values="$2"
  local id_type="$3"

  if [[ -n "$include_values" ]]; then
    ValidateIdList "$id_type" $include_values
  else
    ValidateIdList "$id_type" $discovered_values
  fi
}

ValidateProjectConfig(){
  ValidateProjectFile "$1"
}
