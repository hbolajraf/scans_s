#!/bin/bash
# =============================================================================
# config.sh
# Central runtime configuration.
#
# Real values must be provided as GitLab CI/CD masked variables.
# Defaults are placeholders for local dry-run only.
# =============================================================================

set -o pipefail

: "${PROJECTS_DIR:=./config/projects}"
: "${WORK_DIR:=./work}"
: "${REPORT_BRANCH:=master}"
: "${LOG_LEVEL:=INFO}"
: "${STRICT_REPORTING:=true}"

: "${FORTIFY_BASE_URL:=https://fortify.url:8443}"
: "${FORTIFY_TOKEN:=dummy_token}"

: "${NEXUS_BASE_URL:=https://iqserver.url:8443}"
: "${NEXUS_USER:=dummy_user}"
: "${NEXUS_PAT:=dummy_pat}"

: "${SONAR_BASE_URL:=https://tdo-sonarqube.url}"
: "${SONAR_PAT:=dummy_pat}"

: "${GITLAB_BASE_URL:=https://gitlab-url}"
: "${GITLAB_TOKEN:=dummy_token}"

: "${CONFLUENCE_BASE_URL:=https://confluence.url}"
: "${CONFLUENCE_TOKEN:=dummy_token}"
: "${CONFLUENCE_SPACE:=TCAAS3436}"

# Legacy compatibility variables
fortifyToken="$FORTIFY_TOKEN"
userNexus="$NEXUS_USER"
patNexus="$NEXUS_PAT"
patSonar="$SONAR_PAT"
gitlabToken="$GITLAB_TOKEN"
confluenceToken="$CONFLUENCE_TOKEN"

: "${TMP_DIR:=./tmp}"
mkdir -p "$TMP_DIR"

mkdir -p "$WORK_DIR" "$TMP_DIR"
