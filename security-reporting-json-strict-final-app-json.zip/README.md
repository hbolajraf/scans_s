# Security Reporting Project - JSON Registry Version

## Overview

This project generates security and quality reports for multiple application portfolios identified by Code AP.

It uses JSON files for project configuration instead of Bash arrays.

## Structure

```text
.
├── .gitlab-ci.yml
├── README.md
├── config
│   └── projects
│       ├── AP27346.json
│       ├── AP43782.json
│       ├── AP43797.json
│       └── AP43762.json
├── docs
│   └── ARCHITECTURE.md
└── scripts
    ├── common.sh
    ├── confluence.sh
    ├── projects.sh
    ├── reportings_by_code.sh
    ├── reportings_compare.sh
    ├── reportings_fortify.sh
    ├── reportings_nexus.sh
    ├── reportings_sonarqube.sh
    ├── reportings_sysdig.sh
    └── config
        └── config.sh
```

## config.sh

Located at:

```text
scripts/config/config.sh
```

It contains runtime configuration loaded from GitLab CI variables.

Important variables:

- `FORTIFY_BASE_URL`
- `FORTIFY_TOKEN`
- `NEXUS_BASE_URL`
- `NEXUS_USER`
- `NEXUS_PAT`
- `SONAR_BASE_URL`
- `SONAR_PAT`
- `GITLAB_BASE_URL`
- `GITLAB_TOKEN`
- `CONFLUENCE_BASE_URL`
- `CONFLUENCE_TOKEN`
- `CONFLUENCE_SPACE`
- `REPORT_BRANCH`
- `REPORT_CODE_APS`
- `LOG_LEVEL`

## JSON project registry

Each project is configured in:

```text
config/projects/<CODE_AP>.json
```

Example:

```json
{
  "code_ap": "AP43782",
  "name": "OREO",
  "confluence_page": 598550265,
  "fortify_include": [693131567],
  "nexus_include": ["ed353a787fe04ee9995e6aef055bb3ef"],
  "gitlab_ids": [45836, 47323],
  "sonar_keys": ["p-3293-erelio_web"]
}
```

## Include-only model

There are no EXCLUDE lists anymore.

For Fortify and Nexus:

- if `fortify_include` or `nexus_include` is non-empty, it is authoritative;
- if empty, discovered API values are used;
- every ID is validated before use.

## Previous scan storage

GitLab runners are ephemeral, so previous scans are stored as JSON attachments on the stable parent Confluence page.

Examples:

```text
fortify_summary_AP27346.json
nexus_summary_AP27346.json
sysdig_summary_AP27346.json
sonarqube_summary_AP27346.json
```

## First run behavior

If no previous JSON exists, a zero-value JSON is generated automatically.

## SonarQube dual-bar chart

The script generates a two-bar table for each KPI:

- previous scan
- latest scan

KPIs:

- Bugs
- Vulnerabilities
- CodeSmells
- Coverage
- Duplication

## Logs

All logs go to stderr to avoid corrupting command-substitution values.

Enable debug mode:

```bash
LOG_LEVEL=DEBUG bash scripts/reportings_by_code.sh
```

## Run examples

Run all projects:

```bash
bash scripts/reportings_by_code.sh
```

Run one project:

```bash
REPORT_CODE_APS="AP43782" bash scripts/reportings_by_code.sh
```


## Fixes in this version

This version fixes the issues where reports displayed only IDs and zero values.

### Project names instead of IDs

- Fortify now calls Fortify API to resolve project/application names.
- Nexus now calls Nexus IQ API to resolve application names.
- Sysdig now calls GitLab API to resolve project names.
- SonarQube already uses component keys as labels.

### Real metrics instead of zero values

- Fortify now collects issues by severity from project version issues.
- Nexus now collects latest policy evaluation results.
- SonarQube now collects Bugs, Vulnerabilities, Code Smells, Coverage, Duplication and NCLOC.
- Sysdig now reads `Sysdig-result.json` from GitLab job artifacts.

### Evolution added in details

Evolution tables are now added to both:

- Detail page
- Synthesis page

### Important

If values are still zero, check:

- API tokens
- Branch name in `REPORT_BRANCH`
- Whether reports exist in the tools
- Whether GitLab Sysdig artifacts contain `tmp-secops-services/results/Sysdig-result.json`
- Whether Fortify project versions exist for the requested branch


## Temporary generated files

All generated HTML and JSON files are now stored in:

```text
tmp/
```

Examples:

```text
tmp/
├── reporting_fortify_AP43782.html
├── reporting_nexus_AP43782.html
├── reporting_sonarqube_AP43782.html
├── reporting_sysdig_AP43782.html
├── reporting_OREO.html
├── fortify_summary_AP43782.json
├── nexus_summary_AP43782.json
├── sonarqube_summary_AP43782.json
├── sysdig_summary_AP43782.json
├── trend_fortify_AP43782.html
├── trend_nexus_AP43782.html
├── trend_sonarqube_AP43782.html
└── trend_sysdig_AP43782.html
```

Benefits:
- cleaner repository root
- easier GitLab artifact management
- easier debugging
- easier cleanup
- isolated temporary runtime data

Cleanup is now centralized through:

```bash
CleanupGeneratedFiles
```


## Fix: temporary directory consistency

All generated HTML, JSON, trend files, and downloaded artifacts are now stored in:

```text
tmp/
```

Startup now creates both runtime folders:

```bash
mkdir -p "$WORK_DIR" "$TMP_DIR"
```

The orchestrator verifies generated files before publishing to Confluence:

```bash
AssertGeneratedFile "${TMP_DIR}/reporting_fortify_${codeAP}.html"
AssertGeneratedFile "${TMP_DIR}/reporting_nexus_${codeAP}.html"
AssertGeneratedFile "${TMP_DIR}/reporting_sonarqube_${codeAP}.html"
AssertGeneratedFile "${TMP_DIR}/reporting_sysdig_${codeAP}.html"
```

This fixes errors like:

```text
cat: ./tmp/reporting_MEE.html: No such file or directory
curl: (26) Failed to open/read local data from file/application
```

GitLab artifacts now collect:

```text
tmp/
work/
```


## Strict reporting mode

This version disables silent fake-zero behavior.

The scripts now either:
- collect real values from the APIs, or
- fail with a clear error.

Controlled by:

```bash
STRICT_REPORTING=true
```

If an API call fails, if JSON is invalid, if a Fortify version is missing, if a Nexus report does not exist, or if a Sysdig artifact is missing, the pipeline stops instead of publishing misleading `0` values.

## Why all-zero reports happened before

Previous generated versions used fallback defaults such as:

```json
{"Critical":0,"High":0,"Medium":0,"Low":0,"Total":0}
```

even when API calls failed or reports were missing. That created misleading dashboards. This has been removed from live collection scripts.

Default zero JSON is now used only for **previous scan history on the first run**, not for current scan data.


## Final fix included: safe `ValidateIdList()`

The project now includes the nounset-safe `ValidateIdList()` implementation in:

```text
scripts/projects.sh
```

This fixes the runtime error:

```text
result[@]: unbound variable
```

The function now avoids expanding an empty array when the main script runs with:

```bash
set -euo pipefail
```

It also validates values before any API URL is built:

| Type | Validation |
|---|---|
| numeric | Fortify, GitLab and Confluence numeric IDs |
| nexus | Nexus IQ application IDs |
| sonar | SonarQube component keys |

Rejected values are logged and not used in API calls.

## API collection verification

The archive contains live API-calling implementations:

| Script | API used |
|---|---|
| `reportings_fortify.sh` | Fortify `/api/v1/projects`, `/api/v1/projectVersions/.../issues` |
| `reportings_nexus.sh` | Nexus IQ `/api/v2/applications`, `/api/v2/reports/applications/.../history` |
| `reportings_sonarqube.sh` | SonarQube `/api/measures/component`, `/api/project_analyses/search` |
| `reportings_sysdig.sh` | GitLab `/api/v4/projects`, pipelines, jobs and artifacts |
| `confluence.sh` | Confluence `/rest/api/content` and attachments |

## Strict current-scan behavior

Current scan files are no longer silently defaulted to zero when a collection API fails.

With:

```bash
STRICT_REPORTING=true
```

the pipeline stops if an API call fails, if JSON is invalid, if a mandatory report is missing, or if a required artifact is not found.

Zero default JSON is only used for previous scan history on the first run.


## Enhancement: `_nuget` branch/stage handling

Fortify and Nexus IQ now apply a specific rule for applications whose name contains:

```text
_nuget
```

### Fortify

If the Fortify application/project name contains `_nuget`, the script searches the Fortify version named:

```text
develop
```

instead of the default `REPORT_BRANCH` value, usually `master`.

If no Fortify version/report is found for that branch, the script logs a warning and continues with the next application:

```text
WARN Fortify: no report/version found for <application> on branch develop; continuing
```

### Nexus IQ

If the Nexus IQ application name contains `_nuget`, the script selects a report whose stage/branch/url contains:

```text
develop
```

instead of simply taking the latest report.

If no matching develop report is found, the script logs a warning and continues with the next application:

```text
WARN Nexus: no develop report found for _nuget application <application>; continuing
```

## Missing report behavior

Missing Fortify/Nexus reports no longer break the full reporting execution.

The scripts now:

1. write a warning in logs;
2. add a row in the detail report explaining that the report was not found;
3. continue processing the remaining applications;
4. keep generating synthesis and evolution tables.

API authentication/HTTP/invalid JSON errors are still treated as real failures.


## Enhancement: latest report fallback and Sysdig job selection

### All scans

When no report is found for `REPORT_BRANCH` such as `master`, the scripts now try to use the latest available report instead of stopping.

### Fortify

- `_nuget` applications try branch `develop` first.
- Non-`_nuget` applications try `REPORT_BRANCH` first.
- If the requested branch/version is missing, the script falls back to the latest Fortify version.
- If no version exists at all, it logs a warning, adds a detail row, and continues.

### Nexus IQ

- `_nuget` applications try a report matching `develop`.
- If no develop report exists, the script falls back to the latest Nexus report.
- If no report exists at all, it logs a warning, adds a detail row, and continues.

### SonarQube

- The script tries `REPORT_BRANCH` first.
- If not found, it calls the measures API without a branch to use the default/latest branch.

### Sysdig / GitLab

This fixes cases such as:

```text
job not found for <project>
```

The script now:
1. searches successful pipelines on `REPORT_BRANCH`;
2. falls back to the latest successful pipeline on any branch;
3. prefers the historical job name `secops-services:sysdig_scan_and_quality_gate`;
4. then searches any job containing `sysdig`;
5. then searches any job containing both `container` and `scan`;
6. logs a warning and continues if no job, artifact, or report is found.


## Enhancement: Confluence visual style

The generated Confluence pages now include a shared HTML/CSS style from:

```text
scripts/style.sh
```

Generated pages now have:

- a blue report header;
- improved section titles;
- Confluence-friendly tables;
- alternating row colors;
- hover row highlight;
- better cell padding and borders;
- readable report links;
- colored delta values in evolution tables;
- consistent formatting for detail and synthesis pages.

The style file is generated at runtime in:

```text
tmp/style.html
```

Main helper functions:

```bash
CreateHtmlStyleFile
WrapHtmlReport
```

All detail reports are wrapped with the shared style before being sent to Confluence.

All synthesis pages receive the same style before chart macros and evolution tables.


## Fix: Confluence HTTP 400 during page creation

`CreatePage()` now builds the Confluence REST payload with `jq -n` instead of manual string concatenation.

This safely escapes HTML and quotes in the page body and prevents errors like:

```text
curl: (22) The request URL returned error 400
```

The function now logs:
- HTTP status code;
- page title;
- parent page ID;
- Confluence response body;
- payload file path kept for debugging.

Inline `style="..."` attributes were removed from the initial page creation body to avoid Confluence storage-format rejection.


## Enhancement: per-application JSON history

The pipeline now generates and uploads JSON files at two levels.

### Global portfolio JSON

One summary file per tool and Code AP is still generated and uploaded:

```text
fortify_summary_AP43782.json
nexus_summary_AP43782.json
sysdig_summary_AP43782.json
sonarqube_summary_AP43782.json
```

These files now also contain an `applications` array used for application-level evolution.

### Per-application JSON

Each scanned application also generates its own JSON file:

```text
fortify_AP43782_my_application.json
nexus_AP43782_my_application.json
sysdig_AP43782_my_application.json
sonarqube_AP43782_my_component.json
```

The files are stored in `tmp/` during execution and uploaded to the stable parent Confluence page.

### Main table evolution

The detail and synthesis pages now include application-level evolution tables based on the `applications` arrays in the current and previous JSON payloads.
