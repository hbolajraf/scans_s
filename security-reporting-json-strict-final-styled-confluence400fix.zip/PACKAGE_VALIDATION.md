# Package validation

This archive was regenerated with:
- JSON project registry
- strict real API collection
- safe ValidateIdList implementation
- tmp folder handling
- updated README.md
- updated docs/ARCHITECTURE.md

Required API scripts verified:
- Fortify
- Nexus IQ
- SonarQube
- Sysdig/GitLab
- Confluence


## NuGet enhancement validated

Included:
- Fortify `_nuget` applications use branch `develop`
- Nexus IQ `_nuget` applications select develop report/stage
- Missing Fortify/Nexus reports are warnings and do not break execution
- Detail report includes rows explaining missing reports

## Latest fallback enhancement included
- Sysdig fallback pipeline/job selection
- Fortify latest version fallback
- Nexus latest report fallback
- Sonar default/latest branch fallback


## Style enhancement validated

Included:
- scripts/style.sh
- shared CSS generated to tmp/style.html
- alternating row colors through .security-table tbody tr:nth-child(even)
- detail report wrapped with shared style
- synthesis page receives shared style before charts

## Confluence 400 fix
- CreatePage uses jq -n payload generation
- better HTTP 400 logs
- initial page inline styles removed
