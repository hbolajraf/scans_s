#!/bin/bash
source ./scripts/config/config.sh
source ./scripts/common.sh
source ./scripts/projects.sh

GenerateSysdig(){
  local codeAP="$1"
  mkdir -p "$TMP_DIR"
  LogStep "Sysdig generation for ${codeAP}"

  GitlabGet(){
    local url="$1"
    local context="$2"
    local response code body

    response=$(curl -sS -w '\n%{http_code}' --header "PRIVATE-TOKEN: ${GITLAB_TOKEN}" --location "$url")
    code=$(echo "$response" | tail -1)
    body=$(echo "$response" | sed '$d')

    if ! HttpStatusIsSuccess "$code"; then
      LogWarn "${context}: GitLab API HTTP ${code} - ${url}"
      return 1
    fi

    RequireJson "$body" "$context" || return 1
    echo "$body"
  }

  GetLatestPipelineWithFallback(){
    local id="$1"
    local name="$2"
    local pipelines pipeline ref

    pipelines=$(GitlabGet "${GITLAB_BASE_URL}/api/v4/projects/${id}/pipelines?status=success&ref=${REPORT_BRANCH}" "GitLab successful pipelines for ${name} on ${REPORT_BRANCH}") || echo '[]'
    pipeline=$(echo "$pipelines" | jq -r '.[0].id // empty')

    if [[ -n "$pipeline" ]]; then
      ref="$REPORT_BRANCH"
      printf '%s|%s\n' "$pipeline" "$ref"
      return 0
    fi

    LogWarn "Sysdig: no successful pipeline found for ${name} on branch ${REPORT_BRANCH}; falling back to latest successful pipeline on any branch"

    pipelines=$(GitlabGet "${GITLAB_BASE_URL}/api/v4/projects/${id}/pipelines?status=success" "GitLab latest successful pipelines for ${name}") || echo '[]'
    pipeline=$(echo "$pipelines" | jq -r '.[0].id // empty')
    ref=$(echo "$pipelines" | jq -r '.[0].ref // "latest"')

    [[ -z "$pipeline" ]] && return 1
    printf '%s|%s\n' "$pipeline" "$ref"
  }

  SelectSysdigJob(){
    local jobs="$1"
    local job

    job=$(echo "$jobs" | jq -r '.[]? | select(.name=="secops-services:sysdig_scan_and_quality_gate") | .id' | head -1)
    [[ -n "$job" ]] && { echo "$job"; return 0; }

    job=$(echo "$jobs" | jq -r '.[]? | select((.name // "" | ascii_downcase) | contains("sysdig")) | .id' | head -1)
    [[ -n "$job" ]] && { echo "$job"; return 0; }

    job=$(echo "$jobs" | jq -r '.[]? | select((.name // "" | ascii_downcase) | contains("container") and contains("scan")) | .id' | head -1)
    [[ -n "$job" ]] && { echo "$job"; return 0; }

    return 1
  }

  local ids
  ids=$(ValidateIdList numeric $(GetGitlabIds "$codeAP"))

  if [[ -z "$ids" ]]; then
    LogWarn "Sysdig: no valid GitLab project IDs configured for ${codeAP}; continuing with empty Sysdig report"
  fi

  local detail="${TMP_DIR}/reporting_sysdig_${codeAP}.html"
  local summary="${TMP_DIR}/summary_sysdig_${codeAP}.html"
  local json="${TMP_DIR}/sysdig_summary_${codeAP}.json"

  echo "<div class="security-report-subtitle">Sysdig</div><table class="security-table"><thead><tr><th>Date</th><th>Branche</th><th>Application</th><th>Critical</th><th>High</th><th>Medium</th><th>Low</th><th>Total</th><th>Lien Gitlab</th></tr></thead><tbody>" > "$detail"

  local sumC=0 sumH=0 sumM=0 sumL=0
  local id project selected pipeline ref jobs job artifact file date c h m l t name jobName

  for id in $ids; do
    project=$(GitlabGet "${GITLAB_BASE_URL}/api/v4/projects/${id}" "GitLab project ${id}") || {
      LogWarn "Sysdig: could not read GitLab project ${id}; continuing"
      echo "<tr><td>-</td><td>-</td><td>${id}</td><td colspan=\"5\">GitLab project not readable</td><td>-</td></tr>" >> "$detail"
      continue
    }

    name=$(echo "$project" | jq -r '.name // empty')
    [[ -z "$name" || "$name" == "null" ]] && name="$id"

    selected=$(GetLatestPipelineWithFallback "$id" "$name") || {
      LogWarn "Sysdig: no successful pipeline found for ${name}; continuing"
      echo "<tr><td>-</td><td>${REPORT_BRANCH}</td><td>${name}</td><td colspan=\"5\">No successful pipeline found</td><td>-</td></tr>" >> "$detail"
      continue
    }

    pipeline=$(echo "$selected" | cut -d'|' -f1)
    ref=$(echo "$selected" | cut -d'|' -f2)

    jobs=$(GitlabGet "${GITLAB_BASE_URL}/api/v4/projects/${id}/pipelines/${pipeline}/jobs" "GitLab jobs for ${name} pipeline ${pipeline}") || {
      LogWarn "Sysdig: could not read jobs for ${name}; continuing"
      echo "<tr><td>-</td><td>${ref}</td><td>${name}</td><td colspan=\"5\">Pipeline jobs not readable</td><td>-</td></tr>" >> "$detail"
      continue
    }

    job=$(SelectSysdigJob "$jobs") || {
      LogWarn "Sysdig: job not found for ${name} in pipeline ${pipeline}; continuing"
      echo "<tr><td>-</td><td>${ref}</td><td>${name}</td><td colspan=\"5\">Sysdig job not found</td><td><a href=\"${GITLAB_BASE_URL}/-/pipelines/${pipeline}\" target=\"_blank\">Pipeline</a></td></tr>" >> "$detail"
      continue
    }

    jobName=$(echo "$jobs" | jq -r '.[]? | select(.id=='"${job}"') | .name // "sysdig"' | head -1)
    LogInfo "Sysdig: selected job ${job} (${jobName}) for ${name}"

    artifact="${TMP_DIR}/artifacts_${job}.zip"
    if ! curl -sS --fail --location --output "$artifact" --header "PRIVATE-TOKEN: ${GITLAB_TOKEN}" "${GITLAB_BASE_URL}/api/v4/projects/${id}/jobs/${job}/artifacts"; then
      LogWarn "Sysdig: failed to download artifact for ${name}, job ${job}; continuing"
      echo "<tr><td>-</td><td>${ref}</td><td>${name}</td><td colspan=\"5\">Artifact download failed</td><td><a href=\"${GITLAB_BASE_URL}/-/jobs/${job}\" target=\"_blank\">Job</a></td></tr>" >> "$detail"
      continue
    fi

    if ! unzip -o -j "$artifact" 'tmp-secops-services/results/Sysdig-result.json' -d "$TMP_DIR" >/dev/null 2>&1; then
      LogWarn "Sysdig: Sysdig-result.json not found in artifact for ${name}; continuing"
      echo "<tr><td>-</td><td>${ref}</td><td>${name}</td><td colspan=\"5\">Sysdig-result.json not found in artifact</td><td><a href=\"${GITLAB_BASE_URL}/-/jobs/${job}\" target=\"_blank\">Job</a></td></tr>" >> "$detail"
      rm -f "$artifact"
      continue
    fi

    file="${TMP_DIR}/Sysdig-result.json"
    if ! RequireJson "$(cat "$file")" "Sysdig result for ${name}"; then
      LogWarn "Sysdig: invalid Sysdig-result.json for ${name}; continuing"
      echo "<tr><td>-</td><td>${ref}</td><td>${name}</td><td colspan=\"5\">Invalid Sysdig-result.json</td><td><a href=\"${GITLAB_BASE_URL}/-/jobs/${job}\" target=\"_blank\">Job</a></td></tr>" >> "$detail"
      rm -f "$file" "$artifact"
      continue
    fi

    date=$(jq -r '.SYSDIG[].analysis.IMAGE_ANALYSIS_DATE // "-"' "$file")
    c=$(jq -r '.SYSDIG[].analysis.result.CRITICAL_VULN // 0' "$file")
    h=$(jq -r '.SYSDIG[].analysis.result.HIGH_VULN // 0' "$file")
    m=$(jq -r '.SYSDIG[].analysis.result.MEDIUM_VULN // 0' "$file")
    l=$(jq -r '.SYSDIG[].analysis.result.LOW_VULN // 0' "$file")
    t=$(jq -r '.SYSDIG[].analysis.result.TOTAL_VULN // 0' "$file")

    sumC=$((sumC+c)); sumH=$((sumH+h)); sumM=$((sumM+m)); sumL=$((sumL+l))

    echo "<tr><td>${date}</td><td>${ref}</td><td>${name}</td><td>${c}</td><td>${h}</td><td>${m}</td><td>${l}</td><td>${t}</td><td><a href=\"${GITLAB_BASE_URL}/-/jobs/${job}\" target=\"_blank\">${jobName}</a></td></tr>" >> "$detail"

    rm -f "$file" "$artifact"
  done

  echo "</tbody></table>" >> "$detail"

  local sumT=$((sumC+sumH+sumM+sumL))
  cat > "$summary" <<HTML
<table class="security-table"><thead><tr><th>Level</th><th>Count</th></tr></thead><tbody>
<tr><td>Critical</td><td>${sumC}</td></tr>
<tr><td>High</td><td>${sumH}</td></tr>
<tr><td>Medium</td><td>${sumM}</td></tr>
<tr><td>Low</td><td>${sumL}</td></tr>
<tr><td>Total</td><td>${sumT}</td></tr>
</tbody></table>
HTML

  cat > "$json" <<JSON
{
  "Critical": ${sumC},
  "High": ${sumH},
  "Medium": ${sumM},
  "Low": ${sumL},
  "Total": ${sumT}
}
JSON

  LogInfo "Sysdig totals for ${codeAP}: C=${sumC}, H=${sumH}, M=${sumM}, L=${sumL}, T=${sumT}"
}
