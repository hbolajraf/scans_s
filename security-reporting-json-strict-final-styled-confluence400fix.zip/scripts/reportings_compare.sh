#!/bin/bash
source ./scripts/common.sh

CreateDefaultPreviousSecurityJson(){
  cat > "$1" <<'JSON'
{
  "Critical": 0,
  "High": 0,
  "Medium": 0,
  "Low": 0,
  "Total": 0
}
JSON
}

CreateDefaultPreviousSonarJson(){
  cat > "$1" <<'JSON'
{
  "Bugs": 0,
  "Vulnerabilities": 0,
  "CodeSmells": 0,
  "Coverage": 0,
  "Duplication": 0
}
JSON
}

DeltaClass(){
  local delta="$1"
  awk "BEGIN {
    if (${delta} > 0) print \"kpi-positive\";
    else if (${delta} < 0) print \"kpi-negative\";
    else print \"kpi-neutral\";
  }"
}

CreateSecurityTrendHtml(){
  local previous_json="$1"; local current_json="$2"; local output="$3"; local title="${4:-Evolution sécurité}"
  echo "<div class=\"security-report-subtitle\">${title}</div>" > "$output"
  echo "<table class=\"security-table\"><thead><tr><th>Severity</th><th>Scan précédent</th><th>Dernier scan</th><th>Delta</th></tr></thead><tbody>" >> "$output"

  local k p c d cls
  for k in Critical High Medium Low Total; do
    p=$(JsonNumber "$previous_json" "$k")
    c=$(JsonNumber "$current_json" "$k")
    d=$(awk "BEGIN {print ${c}-${p}}")
    cls=$(DeltaClass "$d")
    echo "<tr><td>${k}</td><td>${p}</td><td>${c}</td><td class=\"${cls}\">${d}</td></tr>" >> "$output"
  done

  echo "</tbody></table>" >> "$output"
}

CreateSonarTrendHtml(){
  local previous_json="$1"; local current_json="$2"; local output="$3"; local title="${4:-Evolution SonarQube}"
  echo "<div class=\"security-report-subtitle\">${title}</div>" > "$output"
  echo "<table class=\"security-table\"><thead><tr><th>KPI</th><th>Scan précédent</th><th>Dernier scan</th><th>Delta</th></tr></thead><tbody>" >> "$output"

  local k p c d cls
  for k in Bugs Vulnerabilities CodeSmells Coverage Duplication; do
    p=$(JsonNumber "$previous_json" "$k")
    c=$(JsonNumber "$current_json" "$k")
    d=$(awk "BEGIN {printf \"%.2f\", ${c}-${p}}")
    cls=$(DeltaClass "$d")
    echo "<tr><td>${k}</td><td>${p}</td><td>${c}</td><td class=\"${cls}\">${d}</td></tr>" >> "$output"
  done

  echo "</tbody></table>" >> "$output"
}

CreateSonarBarChartTable(){
  local previous_json="$1"; local current_json="$2"; local output="$3"
  echo "<table class=\"security-table\"><thead><tr><th>KPI</th><th>Scan précédent</th><th>Dernier scan</th></tr></thead><tbody>" > "$output"

  local k
  for k in Bugs Vulnerabilities CodeSmells Coverage Duplication; do
    echo "<tr><td>${k}</td><td>$(JsonNumber "$previous_json" "$k")</td><td>$(JsonNumber "$current_json" "$k")</td></tr>" >> "$output"
  done

  echo "</tbody></table>" >> "$output"
}
