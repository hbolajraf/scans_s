#!/bin/bash
source ./scripts/config/config.sh
source ./scripts/common.sh
source ./scripts/projects.sh

GenerateFortity(){
  local codeAP="$1"
  local branch="$2"
  mkdir -p "$TMP_DIR"
  LogStep "Fortify generation for ${codeAP}"

  FortifyGet(){
    local url="$1"
    local context="$2"
    local response code body

    response=$(curl -sS -w '\n%{http_code}' -H 'Content-Type: application/json' -H "Authorization: ${FORTIFY_TOKEN}" "$url")
    code=$(echo "$response" | tail -1)
    body=$(echo "$response" | sed '$d')

    if ! HttpStatusIsSuccess "$code"; then
      FailIfStrict "${context}: Fortify API HTTP ${code} - ${url}" || return 1
    fi

    RequireJson "$body" "$context" || return 1
    echo "$body"
  }

  GetDiscoveredProjectIds(){
    local payload
    payload=$(FortifyGet "${FORTIFY_BASE_URL}/api/v1/projects" "Fortify projects list") || return 1
    echo "$payload" | jq -r '.data[]? | select(.name | startswith("'"${codeAP}"'") and (contains("_cd") | not)) | .id'
  }

  GetProjectVersions(){
    local projectId="$1"
    FortifyGet "${FORTIFY_BASE_URL}/api/v1/projects/${projectId}/versions" "Fortify versions for project ${projectId}"
  }

  GetVersionIssues(){
    local versionId="$1"
    FortifyGet "${FORTIFY_BASE_URL}/api/v1/projectVersions/${versionId}/issues?start=0&limit=5000&fields=friority&showhidden=false&showremoved=false&showsuppressed=false&showshortfilenames=false" "Fortify issues for version ${versionId}"
  }

  CountSeverity(){
    local issues="$1"
    local severity="$2"
    echo "$issues" | jq -r '[.data[]? | select((.friority // .severity // .priority // "") == "'"${severity}"'")] | length'
  }

  local discovered include ids
  discovered=$(GetDiscoveredProjectIds) || return 1
  include=$(GetFortifyInclude "$codeAP")
  ids=$(ApplyIncludeOnly "$discovered" "$include" "numeric")

  if [[ -z "$ids" ]]; then
    LogWarn "Fortify: no valid project IDs found for ${codeAP}; continuing with empty Fortify report"
  fi

  local detail="${TMP_DIR}/reporting_fortify_${codeAP}.html"
  local summary="${TMP_DIR}/summary_fortify_${codeAP}.html"
  local json="${TMP_DIR}/fortify_summary_${codeAP}.json"

  echo "<div class="security-report-subtitle">Fortify</div><table class="security-table"><thead><tr><th>Date</th><th>Branche</th><th>Application</th><th>Critical</th><th>High</th><th>Medium</th><th>Low</th><th>Total</th><th>Lien Fortify</th></tr></thead><tbody>" > "$detail"

  local sumC=0 sumH=0 sumM=0 sumL=0
  local id versions app effectiveBranch versionId versionName evalDate issues c h m l total

  for id in $ids; do
    versions=$(GetProjectVersions "$id") || return 1

    app=$(echo "$versions" | jq -r '.data[0].project.name // empty')
    if [[ -z "$app" || "$app" == "null" ]]; then
      LogWarn "Fortify: project name not found for project ${id}; continuing"
      echo "<tr><td>-</td><td>${branch}</td><td>${id}</td><td colspan=\"5\">Project name not found</td><td>-</td></tr>" >> "$detail"
      continue
    fi

    effectiveBranch="$branch"
    if [[ "$app" == *"_nuget"* ]]; then
      effectiveBranch="develop"
      LogInfo "Fortify: ${app} contains _nuget, using branch develop instead of ${branch}"
    fi

    versionId=$(echo "$versions" | jq -r '.data[]? | select(.name=="'"${effectiveBranch}"'") | .id' | head -1)
    versionName="$effectiveBranch"
    evalDate=$(echo "$versions" | jq -r '.data[]? | select(.name=="'"${effectiveBranch}"'") | .currentState.metricEvaluationDate // "-"' | head -1)

    if [[ -z "$versionId" || "$versionId" == "null" ]]; then
      LogWarn "Fortify: no report/version found for ${app} on branch ${effectiveBranch}; falling back to latest available version"
      echo "<tr><td>-</td><td>${effectiveBranch}</td><td>${app}</td><td colspan=\"5\">No Fortify report found for branch ${effectiveBranch}</td><td><a href=\"${FORTIFY_BASE_URL}/html/ssc/project/${id}\" target=\"_blank\">Projet</a></td></tr>" >> "$detail"
      continue
    fi

    issues=$(GetVersionIssues "$versionId") || {
      LogWarn "Fortify: issues not readable for ${app}, version ${versionId}; continuing"
      echo "<tr><td>${evalDate}</td><td>${versionName}</td><td>${app}</td><td colspan=\"5\">Issues API not readable</td><td><a href=\"${FORTIFY_BASE_URL}/html/ssc/version/${versionId}\" target=\"_blank\">Rapport</a></td></tr>" >> "$detail"
      continue
    }

    c=$(CountSeverity "$issues" "Critical")
    h=$(CountSeverity "$issues" "High")
    m=$(CountSeverity "$issues" "Medium")
    l=$(CountSeverity "$issues" "Low")
    total=$((c+h+m+l))

    sumC=$((sumC+c))
    sumH=$((sumH+h))
    sumM=$((sumM+m))
    sumL=$((sumL+l))

    echo "<tr><td>${evalDate}</td><td>${versionName}</td><td>${app}</td><td>${c}</td><td>${h}</td><td>${m}</td><td>${l}</td><td>${total}</td><td><a href=\"${FORTIFY_BASE_URL}/html/ssc/version/${versionId}\" target=\"_blank\">Rapport</a></td></tr>" >> "$detail"
  done

  echo "</tbody></table>" >> "$detail"

  local sumT=$((sumC+sumH+sumM+sumL))
  cat > "$summary" <<HTML
<table class="security-table"><thead><tr><th>Level</th><th>Count</th></tr></thead><tbody>
<tr><td>Critical</td><td>${sumC}</td></tr>
<tr><td>High</td><td>${sumH}</td></tr>
<tr><td>Medium</td><td>${sumM}</td></tr>
<tr><td>Low</td><td>${sumL}</td></tr>
<tr><td>Total</td><td>${sumT}</td></tr>
</tbody></table>
HTML

  cat > "$json" <<JSON
{
  "Critical": ${sumC},
  "High": ${sumH},
  "Medium": ${sumM},
  "Low": ${sumL},
  "Total": ${sumT}
}
JSON

  LogInfo "Fortify totals for ${codeAP}: C=${sumC}, H=${sumH}, M=${sumM}, L=${sumL}, T=${sumT}"
}
