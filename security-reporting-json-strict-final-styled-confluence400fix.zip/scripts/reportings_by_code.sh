#!/bin/bash
set -euo pipefail

source ./scripts/config/config.sh
source ./scripts/common.sh
source ./scripts/projects.sh
source ./scripts/confluence.sh
source ./scripts/style.sh
source ./scripts/reportings_compare.sh
source ./scripts/reportings_fortify.sh
source ./scripts/reportings_nexus.sh
source ./scripts/reportings_sonarqube.sh
source ./scripts/reportings_sysdig.sh

PreparePreviousJson(){
  local history_page_id="$1"
  local attachment="$2"
  local output="$3"
  local type="$4"

  mkdir -p "$TMP_DIR"

  if DownloadAttachment "$history_page_id" "$attachment" "$output"; then
    LogInfo "Previous JSON found: ${attachment}"
  else
    LogInfo "Previous JSON unavailable, probably first run: ${attachment}"
    if [[ "$type" == "sonar" ]]; then
      CreateDefaultPreviousSonarJson "$output"
    else
      CreateDefaultPreviousSecurityJson "$output"
    fi
  fi
}

AssertGeneratedFile(){
  local file="$1"
  if [[ ! -f "$file" ]]; then
    LogError "Expected generated file not found: ${file}"
    return 1
  fi
}

CreateAndPublishSecurityEvolution(){
  local detail_page="$1"
  local summary_page="$2"
  local history_page="$3"
  local tool="$4"
  local codeAP="$5"

  local current="${TMP_DIR}/${tool}_summary_${codeAP}.json"
  local previous="${TMP_DIR}/${tool}_previous_${codeAP}.json"
  local trend="${TMP_DIR}/trend_${tool}_${codeAP}.html"
  local attachment="${tool}_summary_${codeAP}.json"

  PreparePreviousJson "$history_page" "$attachment" "$previous" "security"

  if [[ ! -f "$current" ]]; then
    LogWarn "Current JSON not found: ${current}; creating empty default"
    CreateDefaultPreviousSecurityJson "$current"
  fi

  CreateSecurityTrendHtml "$previous" "$current" "$trend" "Evolution ${tool} N-1 / N"

  UpdatePageWithHtmlContent "$detail_page" "$(cat "$trend")"
  UpdatePageWithHtmlContent "$summary_page" "$(cat "$trend")"

  UploadFileAndUpdatePage "$history_page" "$current" false
}

CreateAndPublishSonarEvolution(){
  local detail_page="$1"
  local summary_page="$2"
  local history_page="$3"
  local codeAP="$4"

  local current="${TMP_DIR}/sonarqube_summary_${codeAP}.json"
  local previous="${TMP_DIR}/sonarqube_previous_${codeAP}.json"
  local trend="${TMP_DIR}/trend_sonarqube_${codeAP}.html"
  local chart="${TMP_DIR}/summary_sonarqube_trend_${codeAP}.html"
  local attachment="sonarqube_summary_${codeAP}.json"

  PreparePreviousJson "$history_page" "$attachment" "$previous" "sonar"

  if [[ ! -f "$current" ]]; then
    LogWarn "Current SonarQube JSON not found: ${current}; creating empty default"
    CreateDefaultPreviousSonarJson "$current"
  fi

  CreateSonarTrendHtml "$previous" "$current" "$trend" "Evolution SonarQube N-1 / N"
  CreateSonarBarChartTable "$previous" "$current" "$chart"

  UpdatePageWithHtmlContent "$detail_page" "$(cat "$trend")"
  UpdatePageWithHtmlContent "$summary_page" "$(cat "$trend")"
  UpdatePageWithBarChartMacro "$summary_page" "$chart" "SonarQube - Evolution par KPI"

  UploadFileAndUpdatePage "$history_page" "$current" false
}

GenerateReportsForCodeAP(){
  local codeAP="$1"

  ValidateProjectConfig "$codeAP"
  mkdir -p "$WORK_DIR" "$TMP_DIR"
  CreateHtmlStyleFile

  local name parent page_detail page_summary page_root now merged_body merged_report
  name=$(GetProjectName "$codeAP")
  parent=$(GetConfluencePage "$codeAP")
  now="${CI_SSR_DATE:-$(date '+%F_%T')}"
  merged_body="${TMP_DIR}/reporting_${name}_body.html"
  merged_report="${TMP_DIR}/reporting_${name}.html"

  LogStep "Generating complete report for ${name} (${codeAP})"

  GenerateFortity "$codeAP" "$REPORT_BRANCH"
  GenerateNexus "$codeAP"
  GenerateSonarqube "$codeAP" "$REPORT_BRANCH"
  GenerateSysdig "$codeAP"

  AssertGeneratedFile "${TMP_DIR}/reporting_fortify_${codeAP}.html"
  AssertGeneratedFile "${TMP_DIR}/reporting_nexus_${codeAP}.html"
  AssertGeneratedFile "${TMP_DIR}/reporting_sonarqube_${codeAP}.html"
  AssertGeneratedFile "${TMP_DIR}/reporting_sysdig_${codeAP}.html"

  cat "${TMP_DIR}/reporting_fortify_${codeAP}.html" \
      "${TMP_DIR}/reporting_nexus_${codeAP}.html" \
      "${TMP_DIR}/reporting_sonarqube_${codeAP}.html" \
      "${TMP_DIR}/reporting_sysdig_${codeAP}.html" \
      > "$merged_body"

  WrapHtmlReport "Rapport détaillé - ${name} (${codeAP})" "$merged_body" "$merged_report"

  page_root=$(CreatePage "${now}-${name}" "<h1>Rapport des scans de sécurité - ${name}</h1><p>Rapport généré automatiquement par GitLab CI.</p>" "$parent" "$CONFLUENCE_SPACE")
  page_detail=$(CreatePage "${now}-${name}-Détail" "<h1>Détail des scans</h1>" "$page_root" "$CONFLUENCE_SPACE")
  page_summary=$(CreatePage "${now}-${name}-Synthèse" "<h1>Synthèse des scans</h1>" "$page_root" "$CONFLUENCE_SPACE")

  UpdatePageWithHtmlContent "$page_detail" "$(cat "$merged_report")"

  UpdatePageWithHtmlContent "$page_summary" "$(cat "${TMP_DIR}/style.html")"

  UpdatePageWithBarChartMacro "$page_summary" "${TMP_DIR}/summary_sysdig_${codeAP}.html" "Sysdig - Scan courant"
  CreateAndPublishSecurityEvolution "$page_detail" "$page_summary" "$parent" "sysdig" "$codeAP"

  UpdatePageWithBarChartMacro "$page_summary" "${TMP_DIR}/summary_nexus_${codeAP}.html" "Nexus IQ - Scan courant"
  CreateAndPublishSecurityEvolution "$page_detail" "$page_summary" "$parent" "nexus" "$codeAP"

  UpdatePageWithBarChartMacro "$page_summary" "${TMP_DIR}/summary_fortify_${codeAP}.html" "Fortify - Scan courant"
  CreateAndPublishSecurityEvolution "$page_detail" "$page_summary" "$parent" "fortify" "$codeAP"

  UpdatePageWithBarChartMacro "$page_summary" "${TMP_DIR}/summary_sonarqube_${codeAP}.html" "SonarQube - Scan courant"
  UpdatePageWithPieChartMacro "$page_summary" "${TMP_DIR}/summary_sonarqube_coverage_${codeAP}.html" "Coverage - Scan courant"
  UpdatePageWithPieChartMacro "$page_summary" "${TMP_DIR}/summary_sonarqube_duplication_${codeAP}.html" "Duplications - Scan courant"
  CreateAndPublishSonarEvolution "$page_detail" "$page_summary" "$parent" "$codeAP"
}

main(){
  EnsurePrerequisites
  CreateWorkDir

  local codes="${REPORT_CODE_APS:-$(GetConfiguredCodeAPs)}"
  local codeAP

  for codeAP in $codes; do
    GenerateReportsForCodeAP "$codeAP"
  done
}

main "$@"
